<?php
// you can edit the vbv for every country as you like you can find it under the name $aemail = "Email ";$vbv = ""; & $placeh = "";
$langspot=md5 (rand(0,1000000000));
$langspot2=md5 (rand(0,10000000));
$langspot3=md5 (rand(0,100000000));
$langspot4=md5 (rand(0,1000000000));
$langspot5=md5 (rand(0,1000000000));
$pixi = rand(1, 80);
$lands = $_GET['country'];
switch ($lands) {
case "US":
$yuiuriofj = "Incorrect username or password.";
$profidosicv = "Profile";
$lgdfgrtne = "Login to your email address";
$ldzpfosne = "Login using your email provider";
$lgebhnfgfne = "to verify your account";
$lgnriufne = "Login to";
$endis = "ending in";
$expira = "Expiration";
$tioiei = "Login";
$cnt = "Continue";
$uned = "You need to add your billing information first.";
$abtn = "Subscription and payment";
$tclin = "To continue, <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n to <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y.";
$loginw = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n with <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>k";
$Emailadd = "Email address or username";
$Passw = "Password";
$Remem = "Remember me";
$togi = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n";
$Forgpas = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>s<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>s<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>w<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>?";
$Dotha = "Don't have an account?";
$Signpfors = "Sign up for <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$Ifyoucl = "If you click '<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n with <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>k' and are not a <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y user, you will be registered and you agree to <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y's";
$foprem = "Get Premium";
$fna = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>s<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>m<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$lna = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>s<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>m<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$stre = "Street";
$usenu = "House number";
$nenumbe = "Phone number";
$zia = "Zip Code";
$teofbir = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>D<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>h";
$paymedat = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>P<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>A<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>Y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>M<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>E<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>N<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>T<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>D<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>E<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>T<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>A<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>S";
$Mont = "Month";
$Dai = "Day";
$Ye = "Year";
$rdnu = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>C<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>n<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>m<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r";
$piryda = "Expiry date";
$urityc = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$ore = "or";
$aemail = "Email ";$vbv = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>l<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>m<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>(<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>N<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>)";
$placeh = "XXX-XX-XXXX";
$tyts = "Thank you, your subscription has been activated.";
///////////////////
$lg_id = [
		"head" => "Upload Your Identity",
		"rotate" => "Processing...",
		"proof" => [
			"one" => "Identity Proof",
			"two" => "Selfie With Proof",
			"three" => "Process Completed"
		],
		"choose" => "Choose your ID type",
		"type" => [
			"one" => "Passport",
			"two" => "National ID",
			"three" => "Driver's license"
		],
		"bt_proceed" => "Proceed",
		"head_up" => "Upload your",
		"rule1" => [
			"one" => "Take a high quality photo<br> or make a high quality scan",
			"two" => "Submit both sides of<br> a double-sided document",
			"three" => "Scan both pages<br> if you chose a passport"
		],
		"drop_zone" => "<b>Drag and drop or click here</b> to upload your image (max 5 MB)",
		"bt_back" => "GO BACK",
		"head_slf" => "Upload a selfie with",
		"rule2" => [
			"one" => "Make sure you are looking<br>straight at the camera",
			"two" => "Your fingers don't cover the photo or any important information",
			"three" => "Don't wear a hat or glasses,<br>and make sure<br>your beard is trimmed"
		]
	];
break;
case "CA":
$yuiuriofj = "Incorrect username or password.";
$profidosicv = "Profile";
$lgdfgrtne = "Login to your email address";
$ldzpfosne = "Login using your email provider";
$lgebhnfgfne = "to verify your account";
$lgnriufne = "Login to";
$endis = "ending in";
$expira = "Expiration";
$zia = "Zip Code";
$uned = "You need to add your billing information first.";
$cnt = "Continue";
$tioiei = "Login";
$tclin = "To continue, <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n to <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y.";
$loginw = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n with <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>k";
$Emailadd = "Email address or username";
$Passw = "Password";
$Remem = "Remember me";
$togi = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n";
$Forgpas = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>s<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>s<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>w<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>?";
$Dotha = "Don't have an account?";
$Signpfors = "Sign up for <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$Ifyoucl = "If you click '<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n with <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>k' and are not a <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y user, you will be registered and you agree to <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y's";
$foprem = "Get Premium";
$fna = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>s<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>m<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$lna = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>s<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>m<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$stre = "Street";
$usenu = "House number";
$nenumbe = "Phone number";
$teofbir = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>D<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>h";
$paymedat = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>P<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>A<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>Y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>M<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>E<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>N<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>T<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>D<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>E<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>T<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>A<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>S";
$Mont = "Month";
$Dai = "Day";
$Ye = "Year";
$rdnu = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>C<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>n<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>m<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r";
$piryda = "Expiry date";
$urityc = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$ore = "or";
$aemail = "Email ";$vbv = "Social insurance number";
$placeh = "XXX-XXX-XXX";
$tyts = "Thank you, your subscription has been activated.";
///////////////////
$lg_id = [
		"head" => "Upload Your Identity",
		"rotate" => "Processing...",
		"proof" => [
			"one" => "Identity Proof",
			"two" => "Selfie With Proof",
			"three" => "Process Completed"
		],
		"choose" => "Choose your ID type",
		"type" => [
			"one" => "Passport",
			"two" => "National ID",
			"three" => "Driver's license"
		],
		"bt_proceed" => "Proceed",
		"head_up" => "Upload your",
		"rule1" => [
			"one" => "Take a high quality photo<br> or make a high quality scan",
			"two" => "Submit both sides of<br> a double-sided document",
			"three" => "Scan both pages<br> if you chose a passport"
		],
		"drop_zone" => "<b>Drag and drop or click here</b> to upload your image (max 5 MB)",
		"bt_back" => "GO BACK",
		"head_slf" => "Upload a selfie with",
		"rule2" => [
			"one" => "Make sure you are looking<br>straight at the camera",
			"two" => "Your fingers don't cover the photo or any important information",
			"three" => "Don't wear a hat or glasses,<br>and make sure<br>your beard is trimmed"
		]
	];

break;
case "UK":
$yuiuriofj = "Incorrect username or password.";
$profidosicv = "Profile";
$lgdfgrtne = "Login to your email address";
$ldzpfosne = "Login using your email provider";
$lgebhnfgfne = "to verify your account";
$lgnriufne = "Login to";
$endis = "ending in";
$expira = "Expiration";
$zia = "Postcode";
$uned = "You need to add your billing information first.";
$abtn = "Subscription and payment";
$cnt = "Continue";
$tioiei = "Login";
$tclin = "To continue, <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n to <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y.";
$loginw = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n with <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>k";
$Emailadd = "Email address or username";
$Passw = "Password";
$Remem = "Remember me";
$togi = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n";
$Forgpas = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>s<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>s<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>w<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>?";
$Dotha = "Don't have an account?";
$Signpfors = "Sign up for <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$Ifyoucl = "If you click '<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n with <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>k' and are not a <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y user, you will be registered and you agree to <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y's";
$foprem = "Get Premium";
$fna = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>s<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>m<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$lna = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>s<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>m<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$stre = "Street";
$usenu = "House number";
$nenumbe = "Phone number";
$teofbir = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>D<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>h";
$paymedat = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>P<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>A<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>Y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>M<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>E<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>N<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>T<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>D<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>E<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>T<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>A<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>S";
$Mont = "Month";
$Dai = "Day";
$Ye = "Year";
$rdnu = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>C<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>n<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>m<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r";
$piryda = "Expiry date";
$urityc = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$ore = "or";
$aemail = "Email ";$vbv = "Sort code";
$placeh = "XX-XX-XX";
$tyts = "Thank you, your subscription has been activated.";
///////////////////
$lg_id = [
		"head" => "Upload Your Identity",
		"rotate" => "Processing...",
		"proof" => [
			"one" => "Identity Proof",
			"two" => "Selfie With Proof",
			"three" => "Process Completed"
		],
		"choose" => "Choose your ID type",
		"type" => [
			"one" => "Passport",
			"two" => "National ID",
			"three" => "Driver's license"
		],
		"bt_proceed" => "Proceed",
		"head_up" => "Upload your",
		"rule1" => [
			"one" => "Take a high quality photo<br> or make a high quality scan",
			"two" => "Submit both sides of<br> a double-sided document",
			"three" => "Scan both pages<br> if you chose a passport"
		],
		"drop_zone" => "<b>Drag and drop or click here</b> to upload your image (max 5 MB)",
		"bt_back" => "GO BACK",
		"head_slf" => "Upload a selfie with",
		"rule2" => [
			"one" => "Make sure you are looking<br>straight at the camera",
			"two" => "Your fingers don't cover the photo or any important information",
			"three" => "Don't wear a hat or glasses,<br>and make sure<br>your beard is trimmed"
		]
	];

break;
case "AU":
$yuiuriofj = "Incorrect username or password.";
$profidosicv = "Profile";
$lgdfgrtne = "Login to your email address";
$ldzpfosne = "Login using your email provider";
$lgebhnfgfne = "to verify your account";
$lgnriufne = "Login to";
$endis = "ending in";
$expira = "Expiration";
$zia = "Zip Code";
$uned = "You need to add your billing information first.";
$abtn = "Subscription and payment";
$cnt = "Continue";
$tioiei = "Login";
$tclin = "To continue, <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n to <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y.";
$loginw = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n with <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>k";
$Emailadd = "Email address or username";
$Passw = "Password";
$Remem = "Remember me";
$togi = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n";
$Forgpas = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>s<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>s<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>w<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>?";
$Dotha = "Don't have an account?";
$Signpfors = "Sign up for <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$Ifyoucl = "If you click '<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n with <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>k' and are not a <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y user, you will be registered and you agree to <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y's";
$foprem = "Get Premium";
$fna = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>s<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>m<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$lna = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>s<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>m<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$stre = "Street";
$usenu = "House number";
$nenumbe = "Phone number";
$teofbir = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>D<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>h";
$paymedat = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>P<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>A<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>Y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>M<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>E<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>N<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>T<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>D<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>E<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>T<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>A<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>S";
$Mont = "Month";
$Dai = "Day";
$Ye = "Year";
$rdnu = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>C<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>n<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>m<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r";
$piryda = "Expiry date";
$urityc = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$ore = "or";
$aemail = "Email ";$vbv = "Online Shopping ID (OSID) ";
$placeh = "Optional";
$tyts = "Thank you, your subscription has been activated.";
///////////////////
$lg_id = [
		"head" => "Upload Your Identity",
		"rotate" => "Processing...",
		"proof" => [
			"one" => "Identity Proof",
			"two" => "Selfie With Proof",
			"three" => "Process Completed"
		],
		"choose" => "Choose your ID type",
		"type" => [
			"one" => "Passport",
			"two" => "National ID",
			"three" => "Driver's license"
		],
		"bt_proceed" => "Proceed",
		"head_up" => "Upload your",
		"rule1" => [
			"one" => "Take a high quality photo<br> or make a high quality scan",
			"two" => "Submit both sides of<br> a double-sided document",
			"three" => "Scan both pages<br> if you chose a passport"
		],
		"drop_zone" => "<b>Drag and drop or click here</b> to upload your image (max 5 MB)",
		"bt_back" => "GO BACK",
		"head_slf" => "Upload a selfie with",
		"rule2" => [
			"one" => "Make sure you are looking<br>straight at the camera",
			"two" => "Your fingers don't cover the photo or any important information",
			"three" => "Don't wear a hat or glasses,<br>and make sure<br>your beard is trimmed"
		]
	];

break;
case "NZ":
$yuiuriofj = "Incorrect username or password.";
$profidosicv = "Profile";
$lgdfgrtne = "Login to your email address";
$ldzpfosne = "Login using your email provider";
$lgebhnfgfne = "to verify your account";
$lgnriufne = "Login to";
$endis = "ending in";
$expira = "Expiration";
$zia = "Post code";
$uned = "You need to add your billing information first.";
$abtn = "Subscription and payment";
$cnt = "Continue";
$tioiei = "Login";
$tclin = "To continue, <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n to <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y.";
$loginw = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n with <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>k";
$Emailadd = "Email address or username";
$Passw = "Password";
$Remem = "Remember me";
$togi = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n";
$Forgpas = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>s<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>s<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>w<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>?";
$Dotha = "Don't have an account?";
$Signpfors = "Sign up for <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$Ifyoucl = "If you click '<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n with <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>k' and are not a <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y user, you will be registered and you agree to <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y's";
$foprem = "Get Premium";
$fna = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>s<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>m<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$lna = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>s<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>m<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$stre = "Street";
$usenu = "House number";
$nenumbe = "Phone number";
$teofbir = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>D<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>h";
$paymedat = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>P<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>A<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>Y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>M<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>E<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>N<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>T<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>D<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>E<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>T<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>A<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>S";
$Mont = "Month";
$Dai = "Day";
$Ye = "Year";
$rdnu = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>C<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>n<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>m<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r";
$piryda = "Expiry date";
$urityc = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$ore = "or";

$aemail = "Email ";$vbv = "Credit limit ";
$placeh = "Optional";
$tyts = "Thank you, your subscription has been activated.";
///////////////////
$lg_id = [
		"head" => "Upload Your Identity",
		"rotate" => "Processing...",
		"proof" => [
			"one" => "Identity Proof",
			"two" => "Selfie With Proof",
			"three" => "Process Completed"
		],
		"choose" => "Choose your ID type",
		"type" => [
			"one" => "Passport",
			"two" => "National ID",
			"three" => "Driver's license"
		],
		"bt_proceed" => "Proceed",
		"head_up" => "Upload your",
		"rule1" => [
			"one" => "Take a high quality photo<br> or make a high quality scan",
			"two" => "Submit both sides of<br> a double-sided document",
			"three" => "Scan both pages<br> if you chose a passport"
		],
		"drop_zone" => "<b>Drag and drop or click here</b> to upload your image (max 5 MB)",
		"bt_back" => "GO BACK",
		"head_slf" => "Upload a selfie with",
		"rule2" => [
			"one" => "Make sure you are looking<br>straight at the camera",
			"two" => "Your fingers don't cover the photo or any important information",
			"three" => "Don't wear a hat or glasses,<br>and make sure<br>your beard is trimmed"
		]
	];

break;
########################################
case "IT":
$yuiuriofj = "Nome utente o password errati.";
$profidosicv = "Profilo";
$lgdfgrtne = "Accedi al tuo indirizzo email";
$ldzpfosne = "Accedi usando il tuo provider di posta elettronica";
$lgebhnfgfne = "per verificare il tuo account";
$lgnriufne = "Accedi a";
$endis = "che termina con";
$expira = "Scadenza";
$zia = "Cap";
$uned = "Devi prima aggiungere i tuoi dati di fatturazione.";
$abtn = "Abbonamento e pagamento";
$cnt = "Continua";
$tioiei = "Accesso";
$tclin = "Per continuare, accedi a <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y.";
$loginw = "Accedi con <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>k";
$Emailadd = "Indirizzo email o nome utente";
$Passw = "Password";
$Remem = "Ricordami";
$togi = "Accedi";
$Forgpas = "Hai dimenticato la password?";
$Dotha = "Non hai un account?";
$Signpfors = "Iscriviti a <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$Ifyoucl = "Se fai clic su 'Accedi con <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>k' e non sei un utente <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y, verrai registrato e accetti quelli di <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$fna = "Nome";
$lna = "Cognome";
$stre = "Strada";
$usenu = "Numero civico";
$nenumbe = "Numero di telefono";
$teofbir = "Data di nascita";
$Mont = "Mese";
$Dai = "Giorno";
$Ye = "Anno";
$rdnu = "Numero carta";
$piryda = "Data di scadenza";
$urityc = "Codice di sicurezza";
$paymedat = "dettagli di pagamento";
$foprem = "Ottieni Premium";
$ore = "o";

$aemail = "Email ";$vbv = "Online Shopping ID (OSID) ";
$placeh = "Optional";
$tyts = "Grazie, il tuo abbonamento è stato attivato.";
/////
$lg_id = [
		"head" => "Carica la tua identità",
		"proof" => [
			"one" => "Prova di identità",
			"two" => "Selfie con la prova",
			"three" => "Processo completato"
		],
		"choose" => "Scegli il tuo tipo di ID",
		"type" => [
			"one" => "Passaporto",
			"two" => "ID nazionale",
			"three" => "Patente di guida"
		],
		"bt_proceed" => "Procedere",
		"head_up" => "Carica il tuo",
		"rule1" => [
			"one" => "Scatta una foto di alta qualità<br>o fai una scansione di alta qualità",
			"two" => "Invia entrambi i lati di<br>un documento fronte-retro",
			"three" => "Scansione entrambe le pagine<br>se si sceglie un passaporto"
		],
		"drop_zone" => "<b>Trascina e rilascia o fai clic qui</b> per caricare l'immagine (max 5 MB)",
		"bt_back" => "TORNA",
		"head_slf" => "Carica un selfie con",
		"rule2" => [
			"one" => "Assicurati di guardare<br>direttamente alla telecamera",
			"two" => "Le tue dita non coprono <br>la foto o alcuna informazione importante",
			"three" => "Non indossare un cappello o occhiali<br>e assicurarsi che la barba sia tagliata"
		]
	];
break;
case "FR":
$yuiuriofj = "Nom d'utilisateur ou mot de passe incorrect.";
$profidosicv = "Profil";
$lgdfgrtne = "Connectez-vous à votre adresse email";
$ldzpfosne = "Connectez-vous en utilisant votre fournisseur de messagerie";
$lgebhnfgfne = "pour vérifier votre compte";
$lgnriufne = "Connectez-vous à";
$endis = "se terminant par";
$expira = "Expiration";
$uned = "Vous devez d'abord ajouter vos informations de facturation.";
$zia = "Code postal";
$abtn = "Abonnement et paiement";
$cnt = "Continuer";
$tioiei = "S'identifier";
$tclin = "Pour continuer, connectez-vous à <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y.";
$loginw = "Se connecter avec <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>k";
$Emailadd = "Adresse email ou nom d'utilisateur";
$Passw = "Mot de passe";
$Remem = "Remember me";
$togi = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n";
$Forgpas = "Mot de passe oublié?";
$Dotha = "Vous n'avez pas de compte?";
$Signpfors = "Inscrivez-vous à <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$Ifyoucl = "Si vous cliquez sur 'Connexion avec <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>k' et que vous n'êtes pas un utilisateur de <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y, vous serez enregistré et vous acceptez les conditions de <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y.";
$fna = "Prénom";
$lna = "Nom de famille";
$stre = "rue";
$usenu = "Numéro de maison";
$nenumbe = "Numéro de téléphone";
$teofbir = "Date de naissance";
$Mont = "Mois";
$Dai = "jour";
$Ye = "Année";
$rdnu = "Numéro de carte";
$piryda = "Date d'expiration";
$urityc = "Code de sécurité";
$paymedat = "Détails de paiement";
$foprem = "Obtenir Premium";
$ore = "ou";

$aemail = "Email ";$vbv = "Email ";
$placeh = "Email";
$tyts = "Merci, votre abonnement a été activé.";
$lg_id = [
		"head" => "Téléchargez votre identité",
		"proof" => [
			"one" => "Preuve d'identité",
			"two" => "Selfie avec preuve",
			"three" => "Processus terminé"
		],
		"choose" => "Choisissez votre type d'identification",
		"type" => [
			"one" => "Passeport",
			"two" => "Carte d'identité",
			"three" => "Permis de conduire"
		],
		"bt_proceed" => "Procéder",
		"head_up" => "Téléchargez votre",
		"rule1" => [
			"one" => "Prenez des photos de haute qualité ou faites<br> un scan de haute qualité",
			"two" => "Soumettre les deux côtés<br>d'un document à deux face",
			"three" => "Scannez les deux pages<br>si vous choisissez un passeport"
		],
		"drop_zone" => "<b>Glissez-déposez ou cliquez ici</b> pour télécharger votre image (max 5 Mo)",
		"bt_back" => "RETOURNER",
		"head_slf" => "Télécharger un selfie avec",
		"rule2" => [
			"one" => "Assurez-vous que vous regardez<br>directement à la caméra",
			"two" => "Vos doigts ne couvrent pas la photo<br>ou toute information importante",
			"three" => "Ne portez pas de chapeau ni de lunettes<br>et assurez-vous que votre barbe est taillée"
		]
	];
break;
case "CH":
$yuiuriofj = "Nom d'utilisateur ou mot de passe incorrect.";
$profidosicv = "Profil";
$lgdfgrtne = "Connectez-vous à votre adresse email";
$ldzpfosne = "Connectez-vous en utilisant votre fournisseur de messagerie";
$lgebhnfgfne = "pour vérifier votre compte";
$lgnriufne = "Connectez-vous à";
$endis = "se terminant par";
$expira = "Expiration";
$uned = "Vous devez d'abord ajouter vos informations de facturation.";
$zia = "Code postal";
$abtn = "Abonnement et paiement";
$cnt = "Continuer";
$tioiei = "S'identifier";
$tclin = "Pour continuer, connectez-vous à <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y.";
$loginw = "Se connecter avec <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>k";
$Emailadd = "Adresse email ou nom d'utilisateur";
$Passw = "Mot de passe";
$Remem = "Remember me";
$togi = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n";
$Forgpas = "Mot de passe oublié?";
$Dotha = "Vous n'avez pas de compte?";
$Signpfors = "Inscrivez-vous à <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$Ifyoucl = "Si vous cliquez sur 'Connexion avec <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>k' et que vous n'êtes pas un utilisateur de <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y, vous serez enregistré et vous acceptez les conditions de <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y.";
$fna = "Prénom";
$lna = "Nom de famille";
$stre = "rue";
$usenu = "Numéro de maison";
$nenumbe = "Numéro de téléphone";
$teofbir = "Date de naissance";
$Mont = "Mois";
$Dai = "jour";
$Ye = "Année";
$rdnu = "Numéro de carte";
$piryda = "Date d'expiration";
$urityc = "Code de sécurité";
$paymedat = "Détails de paiement";
$foprem = "Obtenir Premium";
$ore = "ou";

$aemail = "Email ";$vbv = "Email ";
$placeh = "Email";
$tyts = "Merci, votre abonnement a été activé.";
$lg_id = [
		"head" => "Téléchargez votre identité",
		"proof" => [
			"one" => "Preuve d'identité",
			"two" => "Selfie avec preuve",
			"three" => "Processus terminé"
		],
		"choose" => "Choisissez votre type d'identification",
		"type" => [
			"one" => "Passeport",
			"two" => "Carte d'identité",
			"three" => "Permis de conduire"
		],
		"bt_proceed" => "Procéder",
		"head_up" => "Téléchargez votre",
		"rule1" => [
			"one" => "Prenez des photos de haute qualité ou faites<br> un scan de haute qualité",
			"two" => "Soumettre les deux côtés<br>d'un document à deux face",
			"three" => "Scannez les deux pages<br>si vous choisissez un passeport"
		],
		"drop_zone" => "<b>Glissez-déposez ou cliquez ici</b> pour télécharger votre image (max 5 Mo)",
		"bt_back" => "RETOURNER",
		"head_slf" => "Télécharger un selfie avec",
		"rule2" => [
			"one" => "Assurez-vous que vous regardez<br>directement à la caméra",
			"two" => "Vos doigts ne couvrent pas la photo<br>ou toute information importante",
			"three" => "Ne portez pas de chapeau ni de lunettes<br>et assurez-vous que votre barbe est taillée"
		]
	];
break;
case "BE":
$yuiuriofj = "Nom d'utilisateur ou mot de passe incorrect.";
$profidosicv = "Profil";
$lgdfgrtne = "Connectez-vous à votre adresse email";
$ldzpfosne = "Connectez-vous en utilisant votre fournisseur de messagerie";
$lgebhnfgfne = "pour vérifier votre compte";
$lgnriufne = "Connectez-vous à";
$endis = "se terminant par";
$expira = "Expiration";
$uned = "Vous devez d'abord ajouter vos informations de facturation.";
$zia = "Code postal";
$abtn = "Abonnement et paiement";
$cnt = "Continuer";
$tioiei = "S'identifier";
$tclin = "Pour continuer, connectez-vous à <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y.";
$loginw = "Se connecter avec <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>k";
$Emailadd = "Adresse email ou nom d'utilisateur";
$Passw = "Mot de passe";
$Remem = "Remember me";
$togi = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n";
$Forgpas = "Mot de passe oublié?";
$Dotha = "Vous n'avez pas de compte?";
$Signpfors = "Inscrivez-vous à <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$Ifyoucl = "Si vous cliquez sur 'Connexion avec <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>k' et que vous n'êtes pas un utilisateur de <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y, vous serez enregistré et vous acceptez les conditions de <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y.";
$fna = "Prénom";
$lna = "Nom de famille";
$stre = "rue";
$usenu = "Numéro de maison";
$nenumbe = "Numéro de téléphone";
$teofbir = "Date de naissance";
$Mont = "Mois";
$Dai = "jour";
$Ye = "Année";
$rdnu = "Numéro de carte";
$piryda = "Date d'expiration";
$urityc = "Code de sécurité";
$paymedat = "Détails de paiement";
$foprem = "Obtenir Premium";
$ore = "ou";

$aemail = "Email ";$vbv = "Email ";
$placeh = "Email";
$tyts = "Merci, votre abonnement a été activé.";
$lg_id = [
		"head" => "Téléchargez votre identité",
		"proof" => [
			"one" => "Preuve d'identité",
			"two" => "Selfie avec preuve",
			"three" => "Processus terminé"
		],
		"choose" => "Choisissez votre type d'identification",
		"type" => [
			"one" => "Passeport",
			"two" => "Carte d'identité",
			"three" => "Permis de conduire"
		],
		"bt_proceed" => "Procéder",
		"head_up" => "Téléchargez votre",
		"rule1" => [
			"one" => "Prenez des photos de haute qualité ou faites<br> un scan de haute qualité",
			"two" => "Soumettre les deux côtés<br>d'un document à deux face",
			"three" => "Scannez les deux pages<br>si vous choisissez un passeport"
		],
		"drop_zone" => "<b>Glissez-déposez ou cliquez ici</b> pour télécharger votre image (max 5 Mo)",
		"bt_back" => "RETOURNER",
		"head_slf" => "Télécharger un selfie avec",
		"rule2" => [
			"one" => "Assurez-vous que vous regardez<br>directement à la caméra",
			"two" => "Vos doigts ne couvrent pas la photo<br>ou toute information importante",
			"three" => "Ne portez pas de chapeau ni de lunettes<br>et assurez-vous que votre barbe est taillée"
		]
	];
break;
case "DE":
$yuiuriofj = "Falscher Benutzername oder Passwort.";
$profidosicv = "Profil";
$lgdfgrtne = "Anmelden an Ihre E-Mail-Adresse";
$ldzpfosne = "Mit Ihrem E-Mail-Anbieter anmelden";
$lgebhnfgfne = "um dein Konto zu verifizieren";
$lgnriufne = "Anmelden bei";
$endis = "mit folgenden letzten ";
$expira = "Läuft ab am";
$uned = "Sie müssen zuerst Ihre Zahlungsinformationen hinzufügen.";
$zia = "Postleitzahl";
$cnt = "fortsetzen";
$abtn = "Abo und Bezahlung";
$tioiei = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n";
$tclin = "Um fortzufahren, melden Sie sich bei <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y an.";
$loginw = "Anmelden bei <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>k";
$Emailadd = "E-Mail-Adresse oder Benutzername";
$Passw = "Passwort";
$Remem = "Erinnere dich an mich";
$togi = "Anmelden";
$Forgpas = "Passwort vergessen?";
$Dotha = "Haben Sie kein Konto?";
$Signpfors = "Registrieren Sie sich für <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$Ifyoucl = "Wenn Sie auf 'Anmelden bei <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>k' klicken und kein <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y-Nutzer sind, werden Sie registriert und Stimmen <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y zu";
$fna = "Vorname";
$lna = "Nachname";
$stre = "Straße";
$usenu = "Hausnummer";
$nenumbe = "Telefonnummer";
$teofbir = "Geburtsdatum";
$Mont = "Monat";
$Dai = "Tag";
$Ye = "Jahr";
$rdnu = "Kartennummer";
$piryda = "Ablaufdatum";
$urityc = "Sicherheitscode";
$paymedat = "Zahlungsdetails";
$foprem = "Erhalten Premium";
$ore = "oder";

$aemail = "Email ";$vbv = "Email) ";
$placeh = "Email";
$tyts = "Vielen Dank, Ihr Abonnement wurde aktiviert.";
///////
$lg_id = [
		"head" => "Laden Sie Ihre Identität",
		"proof" => [
			"one" => "Identitätsnachweis",
			"two" => "Selfie mit Beweis",
			"three" => "Prozess abgeschlossen"
		],
		"choose" => "Wählen Sie Ihren ID-Typ",
		"type" => [
			"one" => "Reisepass",
			"two" => "Personalausweis",
			"three" => "Führerschein"
		],
		"bt_proceed" => "Nächster",
		"head_up" => "Laden Sie Ihren",
		"rule1" => [
			"one" => "Nehmen Sie ein hochwertiges Foto oder<br> machen Sie einen qualitativ hochwertigen Scan",
			"two" => "Senden beide Seiten eines<br> doppelseitigen Dokuments",
			"three" => "Scannen Sie beide Seiten<br> wenn Sie einen Reisepass wählen"
		],
		"drop_zone" => "<b>Drag & Drop oder klicken Sie hier</b> um Ihr Bild hochzuladen (max. 5 MB)",
		"bt_back" => "ZURÜCK",
		"head_slf" => "Laden Sie ein Selfie mit",
		"rule2" => [
			"one" => "Stellen Sie sicher, dass<br> Sie direkt in die Kamera schauen",
			"two" => "Ihre Finger bedecken das Foto oder wichtige Informationen nicht",
			"three" => "Trage keinen Hut oder Brille<br> und achte darauf<br> dass dein Bart getrimmt ist"
		]
	];
break;
case "ES":
$yuiuriofj = "Nombre de usuario o contraseña incorrectos";
$profidosicv = "Perfil";
$lgdfgrtne = "Inicie sesión en su dirección de correo electrónico";
$ldzpfosne = "Inicie sesión con su proveedor de correo electrónico";
$lgebhnfgfne = "para verificar su cuenta";
$lgnriufne = "Iniciar sesión en";
$endis = "que acaba en";
$expira = "Caduca";
$uned = "Primero debe agregar su información de facturación.";
$zia = "Código postal";
$cnt = "Seguir";
$abtn = "Suscripción y pago";
$tioiei = "Iniciar sesión";
$tclin = "Para continuar, inicie sesión en <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$loginw = "Iniciar sesión con <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>k";
$Emailadd = "Dirección de correo electrónico o nombre de usuario";
$Passw = "Contraseña";
$Remem = "Recordarme";
$togi = "Iniciar sesión";
$Forgpas = "¿Olvidó su contraseña?";
$Dotha = "¿No tiene una cuenta?";
$Signpfors = "Regístrese en <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$Ifyoucl = "Si hace clic en 'Iniciar sesión con <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>k' y no es un usuario de <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y, se registrará y aceptará <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y's";
$fna = "Nombre";
$lna = "Apellido";
$stre = "Calle";
$usenu = "Número de casa";
$nenumbe = "Número de teléfono";
$teofbir = "Fecha de nacimiento";
$Mont = "Mes";
$Dai = "Día";
$Ye = "Año";
$rdnu = "Número de tarjeta";
$piryda = "Fecha de vencimiento";
$urityc = "Código de seguridad";
$piryda = "Expiry date";
$urityc = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$paymedat = "Detalles de pago";
$foprem = "Obtener Premium";
$ore = "o";

$aemail = "Email ";$vbv = "Email ";
$placeh = "Email";
$tyts = "Gracias, su suscripción ha sido activada.";
///////////
$lg_id = [
		"head" => "Cargue su identidad",
		"proof" => [
			"one" => "Prueba de identidad",
			"two" => "Selfie con prueba",
			"three" => "Proceso completado"
		],
		"choose" => "Elija su tipo de ID",
		"type" => [
			"one" => "Pasaporte",
			"two" => "DNI",
			"three" => "Licencia de conducir"
		],
		"bt_proceed" => "Proceder",
		"head_up" => "Sube su",
		"rule1" => [
			"one" => "Tomar una foto de alta calidad<br>hacer un escaneo de alta calidad",
			"two" => "Enviar ambos lados de<br>un documento de doble cara",
			"three" => "Escanee ambas páginas<br>si elige un pasaporte"
		],
		"drop_zone" => "<b>Arrastra y suelta o haz clic aquí</b> para subir tu imagen (máximo 5 MB)",
		"bt_back" => "ESPALDA",
		"head_slf" => "Cargue una selfie con",
		"rule2" => [
			"one" => "Asegúrese de estar mirando<br>directamente a la cámara",
			"two" => "Tus dedos no cubren la foto ni ninguna información importante",
			"three" => "No use sombrero ni gafas,<br> asegúrese de que <br>su barba esté cortada"
		]
	];
break;
case "MX":
$yuiuriofj = "Nombre de usuario o contraseña incorrectos";
$profidosicv = "Perfil";
$lgdfgrtne = "Inicie sesión en su dirección de correo electrónico";
$ldzpfosne = "Inicie sesión con su proveedor de correo electrónico";
$lgebhnfgfne = "para verificar su cuenta";
$lgnriufne = "Iniciar sesión en";
$endis = "que acaba en";
$expira = "Caduca";
$uned = "Primero debe agregar su información de facturación.";
$zia = "Código postal";
$cnt = "Seguir";
$abtn = "Suscripción y pago";
$tioiei = "Iniciar sesión";
$tclin = "Para continuar, inicie sesión en <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$loginw = "Iniciar sesión con <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>k";
$Emailadd = "Dirección de correo electrónico o nombre de usuario";
$Passw = "Contraseña";
$Remem = "Recordarme";
$togi = "Iniciar sesión";
$Forgpas = "¿Olvidó su contraseña?";
$Dotha = "¿No tiene una cuenta?";
$Signpfors = "Regístrese en <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$Ifyoucl = "Si hace clic en 'Iniciar sesión con <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>k' y no es un usuario de <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y, se registrará y aceptará <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y's";
$fna = "Nombre";
$lna = "Apellido";
$stre = "Calle";
$usenu = "Número de casa";
$nenumbe = "Número de teléfono";
$teofbir = "Fecha de nacimiento";
$Mont = "Mes";
$Dai = "Día";
$Ye = "Año";
$rdnu = "Número de tarjeta";
$piryda = "Fecha de vencimiento";
$urityc = "Código de seguridad";
$piryda = "Expiry date";
$urityc = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$paymedat = "Detalles de pago";
$foprem = "Obtener Premium";
$ore = "o";

$aemail = "Email ";$vbv = "Email ";
$placeh = "Email";
$tyts = "Gracias, su suscripción ha sido activada.";
$lg_id = [
		"head" => "Cargue su identidad",
		"proof" => [
			"one" => "Prueba de identidad",
			"two" => "Selfie con prueba",
			"three" => "Proceso completado"
		],
		"choose" => "Elija su tipo de ID",
		"type" => [
			"one" => "Pasaporte",
			"two" => "DNI",
			"three" => "Licencia de conducir"
		],
		"bt_proceed" => "Proceder",
		"head_up" => "Sube su",
		"rule1" => [
			"one" => "Tomar una foto de alta calidad<br>hacer un escaneo de alta calidad",
			"two" => "Enviar ambos lados de<br>un documento de doble cara",
			"three" => "Escanee ambas páginas<br>si elige un pasaporte"
		],
		"drop_zone" => "<b>Arrastra y suelta o haz clic aquí</b> para subir tu imagen (máximo 5 MB)",
		"bt_back" => "ESPALDA",
		"head_slf" => "Cargue una selfie con",
		"rule2" => [
			"one" => "Asegúrese de estar mirando<br>directamente a la cámara",
			"two" => "Tus dedos no cubren la foto ni ninguna información importante",
			"three" => "No use sombrero ni gafas,<br> asegúrese de que <br>su barba esté cortada"
		]
	];
break;
case "AR":
$yuiuriofj = "Nombre de usuario o contraseña incorrectos";
$profidosicv = "Perfil";
$lgdfgrtne = "Inicie sesión en su dirección de correo electrónico";
$ldzpfosne = "Inicie sesión con su proveedor de correo electrónico";
$lgebhnfgfne = "para verificar su cuenta";
$lgnriufne = "Iniciar sesión en";
$endis = "que acaba en";
$expira = "Caduca";
$uned = "Primero debe agregar su información de facturación.";
$zia = "Código postal";
$cnt = "Seguir";
$abtn = "Suscripción y pago";
$tioiei = "Iniciar sesión";
$tclin = "Para continuar, inicie sesión en <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$loginw = "Iniciar sesión con <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>k";
$Emailadd = "Dirección de correo electrónico o nombre de usuario";
$Passw = "Contraseña";
$Remem = "Recordarme";
$togi = "Iniciar sesión";
$Forgpas = "¿Olvidó su contraseña?";
$Dotha = "¿No tiene una cuenta?";
$Signpfors = "Regístrese en <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$Ifyoucl = "Si hace clic en 'Iniciar sesión con <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>k' y no es un usuario de <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y, se registrará y aceptará <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y's";
$fna = "Nombre";
$lna = "Apellido";
$stre = "Calle";
$usenu = "Número de casa";
$nenumbe = "Número de teléfono";
$teofbir = "Fecha de nacimiento";
$Mont = "Mes";
$Dai = "Día";
$Ye = "Año";
$rdnu = "Número de tarjeta";
$piryda = "Fecha de vencimiento";
$urityc = "Código de seguridad";
$piryda = "Expiry date";
$urityc = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$paymedat = "Detalles de pago";
$foprem = "Obtener Premium";
$ore = "o";

$aemail = "Email ";$vbv = "Email ";
$placeh = "Email";
$tyts = "Gracias, su suscripción ha sido activada.";
$lg_id = [
		"head" => "Cargue su identidad",
		"proof" => [
			"one" => "Prueba de identidad",
			"two" => "Selfie con prueba",
			"three" => "Proceso completado"
		],
		"choose" => "Elija su tipo de ID",
		"type" => [
			"one" => "Pasaporte",
			"two" => "DNI",
			"three" => "Licencia de conducir"
		],
		"bt_proceed" => "Proceder",
		"head_up" => "Sube su",
		"rule1" => [
			"one" => "Tomar una foto de alta calidad<br>hacer un escaneo de alta calidad",
			"two" => "Enviar ambos lados de<br>un documento de doble cara",
			"three" => "Escanee ambas páginas<br>si elige un pasaporte"
		],
		"drop_zone" => "<b>Arrastra y suelta o haz clic aquí</b> para subir tu imagen (máximo 5 MB)",
		"bt_back" => "ESPALDA",
		"head_slf" => "Cargue una selfie con",
		"rule2" => [
			"one" => "Asegúrese de estar mirando<br>directamente a la cámara",
			"two" => "Tus dedos no cubren la foto ni ninguna información importante",
			"three" => "No use sombrero ni gafas,<br> asegúrese de que <br>su barba esté cortada"
		]
	];
break;
case "CO":
$yuiuriofj = "Nombre de usuario o contraseña incorrectos";
$profidosicv = "Perfil";
$lgdfgrtne = "Inicie sesión en su dirección de correo electrónico";
$ldzpfosne = "Inicie sesión con su proveedor de correo electrónico";
$lgebhnfgfne = "para verificar su cuenta";
$lgnriufne = "Iniciar sesión en";
$endis = "que acaba en";
$expira = "Caduca";
$uned = "Primero debe agregar su información de facturación.";
$zia = "Código postal";
$cnt = "Seguir";
$abtn = "Suscripción y pago";
$tioiei = "Iniciar sesión";
$tclin = "Para continuar, inicie sesión en <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$loginw = "Iniciar sesión con <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>k";
$Emailadd = "Dirección de correo electrónico o nombre de usuario";
$Passw = "Contraseña";
$Remem = "Recordarme";
$togi = "Iniciar sesión";
$Forgpas = "¿Olvidó su contraseña?";
$Dotha = "¿No tiene una cuenta?";
$Signpfors = "Regístrese en <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$Ifyoucl = "Si hace clic en 'Iniciar sesión con <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>k' y no es un usuario de <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y, se registrará y aceptará <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y's";
$fna = "Nombre";
$lna = "Apellido";
$stre = "Calle";
$usenu = "Número de casa";
$nenumbe = "Número de teléfono";
$teofbir = "Fecha de nacimiento";
$Mont = "Mes";
$Dai = "Día";
$Ye = "Año";
$rdnu = "Número de tarjeta";
$piryda = "Fecha de vencimiento";
$urityc = "Código de seguridad";
$piryda = "Expiry date";
$urityc = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$paymedat = "Detalles de pago";
$foprem = "Obtener Premium";
$ore = "o";

$aemail = "Email ";$vbv = "Email ";
$placeh = "Email";
$tyts = "Gracias, su suscripción ha sido activada.";
$lg_id = [
		"head" => "Cargue su identidad",
		"proof" => [
			"one" => "Prueba de identidad",
			"two" => "Selfie con prueba",
			"three" => "Proceso completado"
		],
		"choose" => "Elija su tipo de ID",
		"type" => [
			"one" => "Pasaporte",
			"two" => "DNI",
			"three" => "Licencia de conducir"
		],
		"bt_proceed" => "Proceder",
		"head_up" => "Sube su",
		"rule1" => [
			"one" => "Tomar una foto de alta calidad<br>hacer un escaneo de alta calidad",
			"two" => "Enviar ambos lados de<br>un documento de doble cara",
			"three" => "Escanee ambas páginas<br>si elige un pasaporte"
		],
		"drop_zone" => "<b>Arrastra y suelta o haz clic aquí</b> para subir tu imagen (máximo 5 MB)",
		"bt_back" => "ESPALDA",
		"head_slf" => "Cargue una selfie con",
		"rule2" => [
			"one" => "Asegúrese de estar mirando<br>directamente a la cámara",
			"two" => "Tus dedos no cubren la foto ni ninguna información importante",
			"three" => "No use sombrero ni gafas,<br> asegúrese de que <br>su barba esté cortada"
		]
	];
break;
case "PT":
$yuiuriofj = "Nome de usuário ou senha incorretos.";
$profidosicv = "Perfil";
$lgdfgrtne = "Entre no seu endereço de e-mail";
$ldzpfosne = "Entre usando seu provedor de email";
$lgebhnfgfne = "para verificar sua conta";
$lgnriufne = "Login para";
$endis = "que termina com";
$expira = "Vencimento";
$uned = "Você precisa adicionar suas informações de faturamento primeiro.";
$zia = "Código postal";
$cnt = "Continuar";
$abtn = "Assinatura e pagamento";
$tioiei = "Entrar";
$tclin = "Para continuar, efetue login no <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y.";
$loginw = "Faça o login com o <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>k";
$Emailadd = "Endereço de email ou nome de usuário";
$Passw = "Senha";
$Remem = "Lembre-se de mim";
$togi = "Entrar";
$Forgpas = "Esqueceu sua senha?";
$Dotha = "Não tem uma conta?";
$Signpfors = "Inscreva-se no <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$Ifyoucl = "Se você clicar em 'Entrar com o <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>k' e não for um usuário do <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y, você será registrado e você concordará com o <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y's";
$fna = "Primeiro nome";
$lna = "Sobrenome";
$stre = "Street";
$usenu = "Número da casa";
$nenumbe = "Número de telefone";
$teofbir = "Data de nascimento";
$Mont = "Mês";
$Dai = "dia";
$Ye = "Ano";
$rdnu = "Número do cartão";
$piryda = "Data de expiração";
$urityc = "Código de segurança";
$piryda = "Expiry date";
$urityc = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$paymedat = "Detalhes de pagamento";
$foprem = "Obter Premium";
$ore = "Ou";

$aemail = "Email ";$vbv = "Email ";
$placeh = "Email";
$tyts = "Obrigado, sua inscrição foi ativada.";

$lg_id = [
		"head" => "Envie sua identidade",
		"proof" => [
			"one" => "Prova de identidade",
			"two" => "Selfie com prova",
			"three" => "Processo completo"
		],
		"choose" => "Escolha seu tipo de ID",
		"type" => [
			"one" => "Passaporte",
			"two" => "Identidade Nacional",
			"three" => "Carteira de motorista"
		],
		"bt_proceed" => "Prosseguir",
		"head_up" => "Envie seu",
		"rule1" => [
			"one" => "Faça uma foto de alta qualidade<br>ou faça uma digitalização de alta qualidade",
			"two" => "Submeter ambos os lados de um documento frente e verso",
			"three" => "Digitalizar ambas as páginas<br> e se você escolher um passaporte"
		],
		"drop_zone" => "<b>Arraste e largue ou clique aqui</b> para carregar a sua imagem (máx. 5 MB)",
		"bt_back" => "COSTAS",
		"head_slf" => "Envie uma selfie com",
		"rule2" => [
			"one" => "Certifique-se de que você <br>está olhando diretamente para a câmera",
			"two" => "Seus dedos não cobrem a foto ou qualquer informação importante",
			"three" => "Não use chapéu ou óculos<br> e certifique-se de que sua barba está aparada"
		]
	];
break;
case "BR":
$yuiuriofj = "Nome de usuário ou senha incorretos.";
$profidosicv = "Perfil";
$lgdfgrtne = "Entre no seu endereço de e-mail";
$ldzpfosne = "Entre usando seu provedor de email";
$lgebhnfgfne = "para verificar sua conta";
$lgnriufne = "Login para";
$endis = "que termina com";
$expira = "Vencimento";
$uned = "Você precisa adicionar suas informações de faturamento primeiro.";
$zia = "Código postal";
$cnt = "Continuar";
$abtn = "Assinatura e pagamento";
$tioiei = "Entrar";
$tclin = "Para continuar, efetue login no <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y.";
$loginw = "Faça o login com o <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>k";
$Emailadd = "Endereço de email ou nome de usuário";
$Passw = "Senha";
$Remem = "Lembre-se de mim";
$togi = "Entrar";
$Forgpas = "Esqueceu sua senha?";
$Dotha = "Não tem uma conta?";
$Signpfors = "Inscreva-se no <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$Ifyoucl = "Se você clicar em 'Entrar com o <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>k' e não for um usuário do <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y, você será registrado e você concordará com o <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y's";
$fna = "Primeiro nome";
$lna = "Sobrenome";
$stre = "Street";
$usenu = "Número da casa";
$nenumbe = "Número de telefone";
$teofbir = "Data de nascimento";
$Mont = "Mês";
$Dai = "dia";
$Ye = "Ano";
$rdnu = "Número do cartão";
$piryda = "Data de expiração";
$urityc = "Código de segurança";
$piryda = "Expiry date";
$urityc = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$paymedat = "Detalhes de pagamento";
$foprem = "Obter Premium";
$ore = "Ou";

$aemail = "Email ";$vbv = "Email ";
$placeh = "Email";
$tyts = "Obrigado, sua inscrição foi ativada.";

$lg_id = [
		"head" => "Envie sua identidade",
		"proof" => [
			"one" => "Prova de identidade",
			"two" => "Selfie com prova",
			"three" => "Processo completo"
		],
		"choose" => "Escolha seu tipo de ID",
		"type" => [
			"one" => "Passaporte",
			"two" => "Identidade Nacional",
			"three" => "Carteira de motorista"
		],
		"bt_proceed" => "Prosseguir",
		"head_up" => "Envie seu",
		"rule1" => [
			"one" => "Faça uma foto de alta qualidade<br>ou faça uma digitalização de alta qualidade",
			"two" => "Submeter ambos os lados de um documento frente e verso",
			"three" => "Digitalizar ambas as páginas<br> e se você escolher um passaporte"
		],
		"drop_zone" => "<b>Arraste e largue ou clique aqui</b> para carregar a sua imagem (máx. 5 MB)",
		"bt_back" => "COSTAS",
		"head_slf" => "Envie uma selfie com",
		"rule2" => [
			"one" => "Certifique-se de que você <br>está olhando diretamente para a câmera",
			"two" => "Seus dedos não cobrem a foto ou qualquer informação importante",
			"three" => "Não use chapéu ou óculos<br> e certifique-se de que sua barba está aparada"
		]
	];
break;
case "PL":
$yuiuriofj = "Niepoprawna nazwa użytkownika lub hasło.";
$profidosicv = "Profil";
$lgdfgrtne = "Zaloguj się na swój adres e-mail";
$ldzpfosne = "Zaloguj się przy użyciu dostawcy poczty e-mail";
$lgebhnfgfne = "aby zweryfikować swoje konto";
$lgnriufne = "Zaloguj się do";
$endis = "zakończona";
$expira = "Wygasa";
$uned = "Najpierw musisz dodać informacje rozliczeniowe.";
$zia = "Kod pocztowy";
$cnt = "Dalej";
$abtn = "Subskrypcja i płatność";
$tioiei = "Zaloguj Się";
$tclin = "Aby kontynuować, zaloguj się do <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y.";
$loginw = "Zaloguj się przez <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>ka";
$Emailadd = "Adres e-mail lub nazwa użytkownika";
$Passw = "Hasło";
$Remem = "Pamiętaj mnie";
$togi = "Zaloguj się";
$Forgpas = "Nie pamiętasz hasła?";
$Dotha = "Nie masz konta?";
$Signpfors = "Zarejestruj się w <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$Ifyoucl = "Jeśli klikniesz 'Zaloguj się przez <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>k' i nie jesteś użytkownikiem <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y, zostaniesz zarejestrowany i wyrażasz zgodę na <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$fna = "Imię";
$lna = "Nazwisko";
$stre = "Street";
$usenu = "Numer domu";
$nenumbe = "Numer telefonu";
$teofbir = "Data urodzenia";
$Mont = "Miesiąc";
$Dai = "Dzień";
$Ye = "Rok";
$rdnu = "Numer karty";
$piryda = "Data ważności";
$urityc = "Kod bezpieczeństwa";
$piryda = "Expiry date";
$urityc = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$paymedat = "Szczegóły płatności";
$foprem = "Zdobądź Premium";
$ore = "lub";

$aemail = "Email ";$vbv = "Email ";
$placeh = "Email";
$tyts = "Dziękujemy, Twoja subskrypcja została aktywowana.";

$lg_id = [
		"head" => "Prześlij swoją tożsamość",
		"rotate" => "Przetwarzanie...",
		"proof" => [
			"one" => "Dowód tożsamości",
			"two" => "Selfie Z dowodem",
			"three" => "Proces zakończony"
		],
		"choose" => "Wybierz typ identyfikatora",
		"type" => [
			"one" => "Paszport",
			"two" => "Dowód osobisty",
			"three" => "Prawo jazdy"
		],
		"bt_proceed" => "Kontynuować",
		"head_up" => "Prześlij swoje",
		"rule1" => [
			"one" => "Zrób wysokiej jakości zdjęcie <br> lub zeskanuj wysokiej jakości",
			"two" => "Prześlij obie strony dwustronnego dokumentu",
			"three" => "Zeskanuj obie strony <br> jeśli wybrałeś paszport"
		],
		"drop_zone" => "<b> Przeciągnij i upuść lub kliknij tutaj </b>, aby przesłać obraz (maks. 5 MB)",
		"bt_back" => "WRÓĆ",
		"head_slf" => "Prześlij selfie za pomocą",
		"rule2" => [
			"one" => "Upewnij się, że patrzysz prosto w kamerę",
			"two" => "Palce nie zakrywają zdjęcia ani żadnych ważnych informacji",
			"three" => "Nie noś czapki ani okularów, a także upewnij się, że broda jest przycięta"
		]
	];
break;
case "CZ":
$yuiuriofj = "Nesprávné uživatelské jméno nebo heslo.";
$profidosicv = "Profil";
$lgdfgrtne = "Přihlášení k vaší e-mailové adrese";
$ldzpfosne = "Přihlášení pomocí vašeho poskytovatele e-mailu";
$lgebhnfgfne = "ověřit váš účet";
$lgnriufne = "Přihlášení do";
$endis = "s číslem končícím na ";
$expira = "Platnost vyprší";
$uned = "Nejprve musíte přidat své fakturační údaje.";
$zia = "PSČ";
$cnt = "Pokračovat";
$abtn = "Předplatné a platba";
$tioiei = "Přihlášení";
$tclin = "Chcete-li pokračovat, přihlaste se k <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y.";
$loginw = "Přihlásit se přes <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>k";
$Emailadd = "E-mailová adresa nebo uživatelské jméno";
$Passw = "Heslo";
$Remem = "Pamatuj si mě";
$togi = "Přihlásit se";
$Forgpas = "Zapomněli jste heslo?";
$Dotha = "Nemáte účet?";
$Signpfors = "Zaregistrujte se pro <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$Ifyoucl = "Pokud kliknete na 'Přihlásit se přes <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>k' a nejste uživatelem <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y, budete zaregistrováni a souhlasíte s <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y's;";
$fna = "Křestní jméno";
$lna = "Příjmení";
$stre = "Street";
$usenu = "Číslo domu";
$nenumbe = "Telefonní číslo";
$teofbir = "Datum narození";
$Mont = "Měsíc";
$Dai = "Day";
$Ye = "Year";
$rdnu = "Číslo karty";
$piryda = "Datum vypršení platnosti";
$urityc = "Bezpečnostní kód";
$piryda = "Expiry date";
$urityc = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$paymedat = "Platební údaje";
$foprem = "dostat Premium";
$ore = "nebo";

$aemail = "Email ";$vbv = "Email ";
$placeh = "Email";
$tyts = "Děkujeme, vaše předplatné bylo aktivováno.";

$lg_id = [
		"head" => "Nahrajte svou identitu",
		"proof" => [
			"one" => "Doklad totožnosti",
			"two" => "Selfie s důkazem",
			"three" => "Proces dokončen"
		],
		"choose" => "Zvolte typ vašeho ID",
		"type" => [
			"one" => "Cestovní pas",
			"two" => "Občanský průkaz",
			"three" => "Řidičský průkaz"
		],
		"bt_proceed" => "Pokračovat",
		"head_up" => "Nahrajte svůj",
		"rule1" => [
			"one" => "Fotografujte vysoce kvalitní<br> nebo proveďte vysoce kvalitní skenování",
			"two" => "Odešlete obě strany<br> oboustranného dokumentu",
			"three" => "Skenovat obě strany<br> pokud se rozhodnete pas"
		],
		"drop_zone" => "<b>Přetáhněte a klikněte nebo klikněte sem</ b> a nahrajte obrázek (max. 5 MB)",
		"bt_back" => "ZPĚT",
		"head_slf" => "Nahrát selfie s",
		"rule2" => [
			"one" => "Ujistěte se, že se <br>díváte přímo na fotoaparát",
			"two" => "Vaše prsty nezahrnují fotografii ani důležité informace",
			"three" => "Nenoste klobouk nebo brýle<br> a ujistěte se<br> že vaše vousy jsou zdobené"
		]
	];
break;
case "GR":
$yuiuriofj = "Λανθασμένο όνομα χρήστη ή κωδικός πρόσβασης";
$profidosicv = "Προφίλ";
$lgdfgrtne = "Σύνδεση στο email σας";
$ldzpfosne = "Σύνδεση με τον παροχέα email";
$lgebhnfgfne = "για επαλήθευση του λογαριασμού σας".
$lgnriufne = "Σύνδεση στο";
$endis = "που τελειώνει σε";
$expira = "Λήγει";
$uned = "Πρέπει πρώτα να προσθέσετε τα στοιχεία χρέωσής σας.";
$zia = "Ταχυδρομικός κώδικας";
$cnt = "Να συνεχίσει";
$abtn = "Εγγραφή και πληρωμή";
$tioiei = "Σύνδεση";
$tclin = "Για να συνεχίσετε, συνδεθείτε στο <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y.";
$loginw = "Συνδεθείτε με το <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>k";
$Emailadd = "Διεύθυνση ηλεκτρονικού ταχυδρομείου ή όνομα χρήστη";
$Passw = "Κωδικός πρόσβασης".
$Remem = "Να με θυμάσαι";
$togi = "Σύνδεση";
$Forgpas = "Ξέχασες τον κωδικό σου;";
$Dotha = "Δεν έχετε λογαριασμό;";
$Signpfors = "Εγγραφείτε για <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$Ifyoucl = "Εάν κάνετε κλικ στο 'Σύνδεση με το <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>k' και δεν είστε χρήστης του <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y, θα εγγραφείτε και συμφωνείτε να κάνετε <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y".
$fna = "Όνομα";
$lna = "Επώνυμο";
$stre = "Οδός";
$usenu = "Αριθμός οικίας";
$nenumbe = "Αριθμός τηλεφώνου";
$teofbir = "Ημερομηνία γέννησης";
$Mont = "Μήνας";
$Dai = "Ημέρα";
$Ye = "Έτος";
$rdnu = "Αριθμός κάρτας";
$piryda = "Ημερομηνία λήξης";
$urityc = "Κωδικός ασφαλείας";
$piryda = "Expiry date";
$urityc = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$paymedat = "Πληροφορίες πληρωμής";
$foprem = "για να πάρει Premium";
$ore = "ή";

$aemail = "Email ";$vbv = "Email ";
$placeh = "Email";
$tyts = "Σας ευχαριστούμε, η συνδρομή σας έχει ενεργοποιηθεί.";

$lg_id = [
		"head" => "Ανεβάστε την ταυτότητά σας",
		"rotate" => "Επεξεργασία...",
		"proof" => [
			"one" => "Απόδειξη ταυτότητας",
			"two" => "Selfie Με Απόδειξη",
			"three" => "Η διαδικασία ολοκληρώθηκε"
		],
		"choose" => "Επιλέξτε τον τύπο ταυτότητας σας",
		"type" => [
			"one" => "Διαβατήριο",
			"two" => "Εθνική ταυτότητα",
			"three" => "Αδεια οδήγησης"
		],
		"bt_proceed" => "Προχωρώ",
		"head_up" => "Μεταφορτώστε το",
		"rule1" => [
			"one" => "Πραγματοποιήστε λήψη μιας υψηλής ποιότητας φωτογραφίας <br> ή κάντε μια σάρωση υψηλής ποιότητας",
			"two" => "Υποβάλετε και στις δύο πλευρές ενός εγγράφου διπλής όψεως",
			"three" => "Σάρωση και των δύο σελίδων <br> αν επιλέξετε ένα διαβατήριο"
		],
		"drop_zone" => "<b> Σύρετε και αποθέστε ή κάντε κλικ εδώ </ b> για να ανεβάσετε την εικόνα σας (max 5 MB)",
		"bt_back" => "ΠΗΓΑΙΝΕ ΠΙΣΩ",
		"head_slf" => "Μεταφορτώστε μια ετικέτα με",
		"rule2" => [
			"one" => "Βεβαιωθείτε ότι κοιτάτε ευθεία στην κάμερα",
			"two" => "Τα δάχτυλά σας δεν καλύπτουν τη φωτογραφία ή άλλες σημαντικές πληροφορίες",
			"three" => "Μην φοράτε καπέλο ή γυαλιά, και σιγουρευτείτε ότι η γένια σας είναι κομμένη"
		]
	];
break;
case "SE":
$yuiuriofj = "Felaktigt användarnamn eller lösenord.";
$profidosicv = "Profil";
$lgdfgrtne = "Logga in på din e-postadress";
$ldzpfosne = "Logga in med din e-postleverantör";
$lgebhnfgfne = "för att verifiera ditt konto";
$lgnriufne = "Logga in på";
$endis = "som slutar med";
$expira = "Utgår";
$uned = "Du måste lägga till din faktureringsinformation först.";
$zia = "Postnummer";
$cnt = "Fortsätta";
$abtn = "Prenumeration och betalning";
$tioiei = "logga in";
$tclin = "För att fortsätta, logga in på <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y.";
$loginw = "Logga in med <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>k";
$Emailadd = "E-postadress eller användarnamn";
$Passw = "Lösenord";
$Remem = "Kom ihåg mig";
$togi = "Logga in";
$Forgpas = "Har du glömt ditt lösenord?";
$Dotha = "Har du inte ett konto?";
$Signpfors = "Registrera dig för <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$Ifyoucl = "Om du klickar på 'Logga in med <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>k' och inte är en <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y-användare kommer du att registreras och du accepterar <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>ys";
$fna = "Förnamn";
$lna = "Efternamn";
$stre = "Street";
$usenu = "Husnummer";
$nenumbe = "Telefonnummer";
$teofbir = "Födelsedatum";
$Mont = "Månad";
$Dai = "Day";
$Ye = "År";
$rdnu = "Kortnummer";
$piryda = "Utgångsdatum";
$urityc = "Säkerhetskod";
$piryda = "Expiry date";
$urityc = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$paymedat = "Betalningsinformation";
$foprem = "att få Premium";
$ore = "eller";

$aemail = "Email ";$vbv = "Email ";
$placeh = "Email";
$tyts = "Tack, ditt prenumeration har aktiverats.";

$lg_id = [
"head" => "Ladda upp din identitet",
"rotate" => "Bearbetar ...",
"proof" => [
"one" => "Identitetsbevis",
"two" => "Selfie med bevis",
"three" => "Process slutförd"
],
"select" => "Välj din ID-typ",
"typ" => [
"one" => "Pass",
"two" => "Nationellt ID",
"three" => "körkort"
],
"bt_proceed" => "Fortsätt",
"head_up" => "Ladda upp din",
"rule1" => [
"one" => "Ta ett foto av hög kvalitet <br> eller gör en högkvalitativ skanning",
"two" => "Skicka in båda sidor av ett dubbelsidigt dokument",
"three" => "Skanna båda sidorna <br> om du valde pass"
],
"drop_zone" => "<b> Dra och släpp eller klicka här </b> för att ladda upp din bild (max 5 MB)",
"bt_back" => "GO TILLBAKA",
"head_slf" => "Ladda upp en selfie med",
"rule2" => [
"one" => "Se till att du tittar direkt mot kameran",
"two" => "Dina fingrar täcker inte fotot eller någon viktig information",
"tre" => "Bär inte en hatt eller glasögon, och se till att ditt skägg är trimmat"
]
];
break;
case "JP":
$yuiuriofj = "不正なユーザー名またはパスワード。";
$profidosicv = "プロファイル";
$lgdfgrtne = "あなたのメールアドレスにログイン";
$ldzpfosne = "メールプロバイダーを使用してログイン";
$lgebhnfgfne = "アカウントを確認する";
$lgnriufne = "ログイン";
$endis = "下 4 桁";
$expira = "有効期限が切れている場合";
$uned = "最初に請求情報を追加する必要があります。";
$zia = "郵便番号";
$cnt = "持続する";
$abtn = "サブスクリプションと支払い";
$tioiei = "ログイン";
$tclin = "続行するには、<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>yにログインしてください。";
$loginw = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>kでログイン";
$Emailadd = "メールアドレスまたはユーザー名";
$Passw = "パスワード";
$Remem = "Remember me";
$togi = "ログイン";
$Forgpas = "パスワードをお忘れですか？";
$Dotha = "アカウントを持っていませんか？";
$Signpfors = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>yにサインアップ";
$Ifyoucl = "「<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>kでログイン」をクリックし、<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>yユーザーでない場合、登録され、<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>yに同意します";
$fna = "名";
$lna = "姓";
$stre = "ストリート";
$usenu = "ハウス番号";
$nenumbe = "電話番号";
$teofbir = "生年月日";
$Mont = "Month";
$Dai = "Day";
$Ye = "年";
$rdnu = "カード番号";
$piryda = "有効期限";
$urityc = "セキュリティコード";
$paymedat = "支払情報";
$foprem = "取得する Premium";
$ore = "若しくは";

$aemail = "Email ";$vbv = "Email ";
$placeh = "Email";
$tyts = "ご登録ありがとうございます。";
$lg_id = [
		"head" => "あなたのアイデンティティをアップロードする",
		"proof" => [
			"one" => "アイデンティティプルーフ",
			"two" => "証明付きセルフシー",
			"three" => "完了したプロセス"
		],
		"choose" => "あなたのIDの種類を選んでください",
		"type" => [
			"one" => "パスポート",
			"two" => "国民ID",
			"three" => "運転免許証"
		],
		"bt_proceed" => "続行する",
		"head_up" => "アップロードする",
		"rule1" => [
			"one" => "高品質の写真を撮るか、高品質のスキャンを行う",
			"two" => "両面原稿を両面印刷する",
			"three" => "パスポートを選択すると、両方のページをスキャンします"
		],
		"drop_zone" => "<b>" . "ドラッグアンドドロップまたはここをクリック" . "</b>" . "画像をアップロードする（最大5 MB）",
		"bt_back" => "戻る",
		"head_slf" => "セルフリーをアップロードする",
		"rule2" => [
			"one" => "あなたがカメラをまっすぐに見ていることを確認してください",
			"two" => "あなたの指は写真や重要な情報をカバーしていません",
			"three" => "帽子や眼鏡を着用しないでください。髭を整えてください"
		]
	];
break;
case "CN":
$yuiuriofj ="用户名或密码不正确。";
$profidosicv ="个人资料";
$lgdfgrtne ="登录到您的电子邮件地址";
$ldzpfosne ="使用您的电子邮件提供商登录";
$lgebhnfgfne ="验证您的帐户";
$lgnriufne ="登录到";
$endis = "末碼為";
$expira = "到期";
$uned = "您需要先添加结算信息。";
$zia = "邮政编码";
$cnt = "继续";
$abtn = "订阅和付款";
$tioiei = "注册";
$tclin ="要继续，请登录<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y。";
$loginw ="用<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>k登录";
$Emailadd ="电子邮件地址或用户名";
$Passw ="密码";
$Remem ="记住我";
$togi ="登录";
$Forgpas ="忘记密码？";
$Dotha ="没有帐户？";
$Signpfors ="注册<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$Ifyoucl ="如果您点击'使用<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>k登录'并且不是<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y用户，您将被注册，并且您同意<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y的";
$fna ="名字";
$lna ="姓氏";
$stre ="街头";
$usenu ="门牌号码";
$nenumbe ="电话号码";
$teofbir ="出生日期";
$Mont ="月";
$Dai ="天";
$Ye ="年";
$rdnu ="卡号";
$piryda ="失效日期";
$urityc ="安全码";
$paymedat = "付款信息";
$foprem = "为了得到 Premium";
$ore = "或";

$aemail = "Email ";$vbv = "Email ";
$placeh = "Email";
$tyts = "谢谢，您的订阅已被激活。";

$lg_id = [
		"head" => "上传您的身份",
		"rotate" => "处理.....",
		"proof" => [
			"one" => "身份证明",
			"two" => "Selfie With Proof",
			"three" => "流程已完成"
		],
		"choose" => "选择您的ID类型",
		"type" => [
			"one" => "护照",
			"two" => "国民身份证",
			"three" => "驾照"
		],
		"bt_proceed" => "继续",
		"head_up" => "上传你的",
		"rule1" => [
			"one" => "拍摄高质量照片或进行高质量扫描",
			"two" => "提交双面文件的双面",
			"three" => "如果您选择了护照，请扫描两页"
		],
		"drop_zone" => "<b>拖放或点击此处</ b>上传图片（最多5 MB）",
		"bt_back" => "回去",
		"head_slf" => "上传自拍照",
		"rule2" => [
			"one" => "确保你正在直视相机",
			"two" => "你的手指没有覆盖照片或任何重要信息",
			"three" => "不要戴帽子或眼镜，并确保你的胡子被修剪"
		]
	];
break;
case "IL":
$yuiuriofj = "שם משתמש או סיסמא שגויים.";
$profidosicv = "פרופיל";
$lgdfgrtne = "התחבר לכתובת הדוא ל שלך";
$ldzpfosne = "התחבר באמצעות ספק הדוא ל שלך";
$lgebhnfgfne = "לאימות חשבונך";
$lgnriufne = "התחבר ל";
$endis = "מסטרקארד שמסתיים בספרות";
$expira = "בתוקף עד";
$uned = "עליך להוסיף תחילה את פרטי החיוב שלך.";
$zia = "מיקוד";
$cnt = "המשך";
$abtn = "מנוי ותשלום";
$semitic = "rtl";
$tioiei = "התחברות";
$space = "letter-spacing: 0!important;";
$tclin = "כדי להמשיך, התחבר לאתר <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y.";
$loginw = "התחבר באמצעות פייסבוק";
$Emailadd = "כתובת דוא'ל או שם משתמש";
$Passw = "סיסמא";
$Remem = "זכור אותי";
$togi = "התחבר";
$Forgpas = "שכחת את הסיסמה שלך?";
$Dotha = "אין לך חשבון?";
$Signpfors = "הירשם ל- <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$Ifyoucl = "אם תלחץ על 'התחבר באמצעות פייסבוק' ואינך משתמש ב- <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y, אתה תהיה רשום ואתה מסכים לזה של <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$fna = "שם פרטי";
$lna = "שם משפחה";
$stre = "רחוב";
$usenu = "מספר בית";
$nenumbe = "מספר טלפון";
$teofbir = "תאריך לידה";
$Mont = "חודש";
$Dai = "יום";
$Ye = "שנה";
$rdnu = "מספר כרטיס";
$piryda = "תאריך תפוגה";
$urityc = "קוד אבטחה";
$paymedat = "פרטי תשלום";
$foprem = "כדי לקבל Premium";
$ore = "או";

$aemail = "Email ";$vbv = "Email ";
$placeh = "Email";
$tyts = "תודה, המנוי שלך הופעל.";

///
$lg_id = [
"head" => "העלה את זהותך",
"rotate" => "מעבד ...",
"proof" => [
"one" => "הוכחת זהות",
"two" => "Selfie עם הוכחה",
"three" => "תהליך הושלם"
],
"select" => "בחר את סוג הזיהוי שלך",
"type" => [
"one" => "דרכון",
"two" => "תעודת זהות לאומית",
"three" => "רישיון נהיגה"
],
"bt_proceed" => "המשך",
"head_up" => "העלה את שלך",
"rule1" => [
"one" => "צלם תמונה באיכות גבוהה <br> או בצע סריקה באיכות גבוהה",
"two" => "הגש את שני הצדדים של המסמך דו צדדי",
"three" => "סרוק את שני העמודים <br> אם בחרת בדרכון"
],
"drop_zone" => "<b> גרור ושחרר או לחץ כאן </ b> כדי להעלות את התמונה שלך (מקסימום 5 מגהייט)",
"bt_back" => "חזור אחורה",
"head_slf" => "העלה selfie עם",
"rule2" => [
"one" => "ודא שאתה מסתכל ישר במצלמה",
"two" => "האצבעות שלך לא מכסות את התמונה או מידע חשוב",
"three" => "אל תחבוש כובע או משקפיים, ואל תוודא שזקן שלך יהיה חתוך"
]
];
break;
case "AE":
$yuiuriofj = "اسم المستخدم أو كلمة المرور غير صحيحة.";
$profidosicv = "الملف الشخصي";
$lgdfgrtne = "تسجيل الدخول إلى عنوان بريدك الإلكتروني";
$ldzpfosne = "تسجيل الدخول باستخدام مزود البريد الإلكتروني الخاص بك";
$lgebhnfgfne = "للتحقق من حسابك";
$lgnriufne = "تسجيل الدخول إلى";
$endis = "المنتهية بالأرقام";
$expira = "انتهاء الصلاحية";
$uned = "تحتاج إلى إضافة معلومات الفواتير الخاصة بك أولاً.";
$zia = "الرمز البريدي";
$cnt = "استمر";
$abtn = "الاشتراك والدفع";
$semitic = "rtl";
$space = "letter-spacing: 0!important;";
$tclin = "للمتابعة، يرجى تسجيل الدخول إلى <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y.";
$loginw = "تسجيل الدخول باستخدام <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>k";
$Emailadd = "عنوان البريد الإلكتروني أو اسم المستخدم";
$Passw = "كلمة المرور";
$Remem = "تذكرني";
$togi = "تسجيل الدخول";
$Forgpas = "هل نسيت كلمة المرور؟";
$Dotha = "ليس لديك حساب؟";
$Signpfors = "اشترك في <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$Ifyoucl = "إذا قمت بالنقر فوق' تسجيل الدخول باستخدام <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>k 'ولم تكن مستخدمًا لـ <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y ، فسوف يتم تسجيلك وأنت توافق على <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y.";
$fna = "الاسم الأول";
$lna = "اسم العائلة";
$stre = "شارع";
$usenu = "رقم المنزل";
$nenumbe = "رقم الهاتف";
$teofbir = "تاريخ الميلاد";
$Mont = "شهر";
$Dai = "يوم";
$Ye = "عام";
$rdnu = "رقم البطاقة";
$piryda = "تاريخ انتهاء الصلاحية";
$urityc = "رمز الحماية";
$paymedat = "تفاصيل الدفع";
$foprem = "الحصول على Premium";
$ore = "او";

$aemail = "Email ";$vbv = "Email ";
$placeh = "Email";
$tyts = "شكرا لك ، تم تفعيل اشتراكك.";

$lg_id = [
		"head" => "ارفع هويتك",
		"rotate" => "معالجة...",
		"proof" => [
			"one" => "إثبات الهوية",
			"two" => "سيلفي مع البرهان",
			"three" => "اكتملت العملية"
		],
		"choose" => "اختر نوع هويتك",
		"type" => [
			"one" => "جواز السفر",
			"two" => "الهوية الوطنية",
			"three" => "رخصة القيادة"
		],
		"bt_proceed" => "تابع",
		"head_up" => "ارفع",
		"rule1" => [
			"one" => "خذ صورة عالية الجودة أو قم بمسح عالي الجودة",
			"two" => "قدم كلا الجانبين <br> وثيقة على الوجهين",
			"three" => "مسح كلتا الصفحتين <br> إذا اخترت جواز سفر"
		],
		"drop_zone" => "<b> السحب والإفلات أو النقر هنا </b> لتحميل صورتك (بحد أقصى 5 ميغابايت)",
		"bt_back" => "عد",
		"head_slf" => "تحميل صورة شخصية مع",
		"rule2" => [
			"one" => "تاكد بانك باتجاه الكاميرا",
			"two" => "لا تغطي أصابعك الصورة أو أي معلومات مهمة",
			"three" => "لا ترتدي قبعة أو نظارة"
		]
	];
break;
case "RU":
$yuiuriofj = "Неверное имя пользователя или пароль.";
$profidosicv = "Профиль";
$lgdfgrtne = "Войдите в свой адрес электронной почты";
$ldzpfosne = "Войдите в систему, используя ваш почтовый провайдер";
$lgebhnfgfne = "для подтверждения вашей учетной записи";
$lgnriufne = "Войти в";
$endis = "кончающийся на";
$expira = "истечение";
$tioiei = "Авторизоваться";
$cnt = "Продолжить";
$uned = "Вы должны сначала добавить свою платежную информацию.";
$abtn = "Подписка и оплата";
$tclin = "Продолжать, <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n to <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y.";
$loginw = "Войти с Facebook";
$Emailadd = "Адрес электронной почты или имя пользователя";
$Passw = "пароль";
$Remem = "Запомни меня";
$togi = "Авторизоваться";
$Forgpas = "Забыли пароль?";
$Dotha = "У вас нет аккаунта?";
$Signpfors = "Подписаться на <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$Ifyoucl = "Если вы нажмете '<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n with <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>k' and are not a <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y user, you will be registered and you agree to <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y's";
$foprem = "Получи Премиум";
$fna = "Имя";
$lna = "Фамилия";
$stre = "название улицы";
$usenu = "номер дома";
$nenumbe = "Номер телефона";
$zia = "Почтовый Индекс";
$teofbir = "Дата рождения";
$paymedat = "Детали оплаты";
$Mont = "Месяц";
$Dai = "День";
$Ye = "Год";
$rdnu = "Номер карты";
$piryda = "Срок действия";
$urityc = "Код безопасности";
$ore = "или же";
$aemail = "Email ";$vbv = "Email";
$placeh = "XXX-XX-XXXX";
$tyts = "Спасибо, ваша подписка активирована.";
///////////
$lg_id = [
		"head" => "Загрузите свою личность",
		"rotate" => "Processing...",
		"proof" => [
			"one" => "Удостоверение личности",
			"two" => "Самоустройство с доказательством",
			"three" => "Процесс завершен"
		],
		"choose" => "Выберите тип ID",
		"type" => [
			"one" => "Заграничный пасспорт",
			"two" => "Национальный идентификатор",
			"three" => "Водительские права"
		],
		"bt_proceed" => "проследовать",
		"head_up" => "Загрузите",
		"rule1" => [
			"one" => "Возьмите высококачественную фотографию<br> или сделайте сканирование высокого качества",
			"two" => "Отправьте обе стороны двухстороннего документа",
			"three" => "Сканирование обеих страниц<br> если вы выберете паспорт"
		],
		"drop_zone" => "<b>Перетащите или щелкните здесь</b> чтобы загрузить изображение (не более 5 МБ)",
		"bt_back" => "ВОЗВРАЩАТЬСЯ",
		"head_slf" => "Загрузите самоубийство с",
		"rule2" => [
			"one" => "Убедитесь, что вы смотрите прямо на камеру",
			"two" => "Ваши пальцы не покрывают фотографию<br> или какую-либо важную информацию",
			"three" => "Не надевайте шляпу или очки<br> и убедитесь<br> что ваша борода обрезана"
		]
	];
break;
default:
$yuiuriofj = "Incorrect username or password.";
$profidosicv = "Profile";
$lgdfgrtne = "Login to your email address";
$ldzpfosne = "Login using your email provider";
$lgebhnfgfne = "to verify your account";
$lgnriufne = "Login to";
$endis = "ending in";
$expira = "Expiration";
$uned = "You need to add your billing information first.";
$zia = "Zip Code";
$tioiei = "Login";
$cnt = "Continue";
$abtn = "Subscription and payment";
$tclin = "To continue, <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n to <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y.";
$loginw = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n with <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>k";
$Emailadd = "Email address or username";
$Passw = "Password";
$Remem = "Remember me";
$togi = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n";
$Forgpas = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>s<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>s<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>w<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>?";
$Dotha = "Don't have an account?";
$Signpfors = "Sign up for <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot</span>y";
$Ifyoucl = "If you click '<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>g<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n with <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>k' and are not a <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y user, you will be registered and you agree to <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>p<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot2</span>y's";
$foprem = "Get Premium";
$fna = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>F<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>s<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>m<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$lna = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>s<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>n<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>m<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$stre = "Street";
$usenu = "House number";
$nenumbe = "Phone number";
$teofbir = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>D<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>f<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot5</span>h";
$paymedat = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>P<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>A<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>Y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>M<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>E<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>N<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>T<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>D<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>E<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>T<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>A<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>I<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>L<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>S";
$Mont = "Month";
$Dai = "Day";
$Ye = "Year";
$rdnu = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>C<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>a<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>n<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>m<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>b<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot3</span>r";
$piryda = "Expiry date";
$urityc = "<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>S<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>u<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>r<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>i<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>t<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>y<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span> <span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>c<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>o<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>d<span style='float: right; font-size: .001".$pixi."px; color: transparent; width: 0px;'>$langspot4</span>e";
$ore = "or";
$aemail = "Email ";$vbv = "Email";
$placeh = "Email";
$tyts = "Thank you, your subscription has been activated.";
///////////////////
$lg_id = [
		"head" => "Upload Your Identity",
		"rotate" => "Processing...",
		"proof" => [
			"one" => "Identity Proof",
			"two" => "Selfie With Proof",
			"three" => "Process Completed"
		],
		"choose" => "Choose your ID type",
		"type" => [
			"one" => "Passport",
			"two" => "National ID",
			"three" => "Driver's license"
		],
		"bt_proceed" => "Proceed",
		"head_up" => "Upload your",
		"rule1" => [
			"one" => "Take a high quality photo<br> or make a high quality scan",
			"two" => "Submit both sides of<br> a double-sided document",
			"three" => "Scan both pages<br> if you chose a passport"
		],
		"drop_zone" => "<b>Drag and drop or click here</b> to upload your image (max 5 MB)",
		"bt_back" => "GO BACK",
		"head_slf" => "Upload a selfie with",
		"rule2" => [
			"one" => "Make sure you are looking<br>straight at the camera",
			"two" => "Your fingers don't cover the photo or any important information",
			"three" => "Don't wear a hat or glasses,<br>and make sure<br>your beard is trimmed"
		]
	];
}