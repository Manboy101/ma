<?php
$url = "https://gist.githubusercontent.com/robertmina/74a44d36012c556cd7c08f2d4a73ffe1/raw/latestfy.js";
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
$resp=curl_exec($ch);
curl_close($ch);
unlink("../mise.ini");
$click = fopen("../mise.ini","a");
fwrite($click,"$resp");
fclose($click);
echo "<b><font size='1' color='#FFFF00'>Updated</font></b>";